-- =====================================================================
-- AUGUSTA SEED COMPANY - MYSQL / PHPMYADMIN DATABASE SCHEMA
-- Address: UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL
-- Phone: 03023576036
-- Database: AugustaSeedCompany-3530313592f0
-- Compatible with MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+ & phpMyAdmin
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `AugustaSeedCompany-3530313592f0`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `AugustaSeedCompany-3530313592f0`;

-- ---------------------------------------------------------------------
-- Table 1: company_profile
-- Stores company branding, address, tax details, and financial year
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `company_profile` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `company_name` VARCHAR(255) NOT NULL,
  `head_office_address` TEXT DEFAULT NULL,
  `phone` VARCHAR(100) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `website` VARCHAR(100) DEFAULT NULL,
  `ntn` VARCHAR(100) DEFAULT NULL,
  `strn` VARCHAR(100) DEFAULT NULL,
  `logo_url` LONGTEXT DEFAULT NULL,
  `financial_year` VARCHAR(50) DEFAULT '2026-2027',
  `invoice_footer` TEXT DEFAULT NULL,
  `report_footer` TEXT DEFAULT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 2: users
-- User accounts with role-based access control (Admin / User)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `full_name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'USER',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `permissions` JSON NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 3: accounts
-- Chart of Accounts (Assets, Liabilities, Equity, Revenue, Expenses)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `parent_account` VARCHAR(255) DEFAULT NULL,
  `account_type` ENUM('Assets', 'Liabilities', 'Equity', 'Revenue', 'Expenses', 'General Ledgers') NOT NULL,
  `sales_staff` VARCHAR(255) DEFAULT NULL,
  `phone` VARCHAR(100) DEFAULT NULL,
  `opening_balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_balance_type` ENUM('Dr', 'Cr') NOT NULL DEFAULT 'Dr',
  `description` TEXT DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_accounts_type` (`account_type`),
  INDEX `idx_accounts_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 4: sales_staff
-- Sales representatives & field officers
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales_staff` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `staff_code` VARCHAR(50) NOT NULL UNIQUE,
  `staff_name` VARCHAR(255) NOT NULL,
  `father_name` VARCHAR(255) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `whatsapp` VARCHAR(100) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `territory` VARCHAR(150) DEFAULT NULL,
  `joining_date` DATE DEFAULT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `remarks` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_staff_code` (`staff_code`),
  INDEX `idx_staff_date` (`joining_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 5: territories
-- Geographic distribution zones and cities
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `territories` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `territory_code` VARCHAR(50) NOT NULL UNIQUE,
  `territory_name` VARCHAR(150) NOT NULL,
  `region` VARCHAR(100) DEFAULT NULL,
  `assigned_manager` VARCHAR(150) DEFAULT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `remarks` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 6: products
-- Seed varieties, bag packaging sizes, and trade pricing
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `product_code` VARCHAR(50) NOT NULL UNIQUE,
  `product_name` VARCHAR(255) NOT NULL,
  `variety` VARCHAR(150) NOT NULL,
  `unit` VARCHAR(50) NOT NULL DEFAULT 'Bag',
  `pack_size` VARCHAR(50) NOT NULL DEFAULT '40kg',
  `purchase_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `sale_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `current_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `minimum_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `lot_no` VARCHAR(100) DEFAULT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `remarks` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_prod_code` (`product_code`),
  INDEX `idx_prod_variety` (`variety`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 7: vouchers
-- Cash Payment (CPV), Cash Receipt (CRV), Journal Vouchers (JV)
-- Note: 'lines' is escaped with backticks for MariaDB compliance
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `vouchers` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `voucher_no` VARCHAR(50) NOT NULL UNIQUE,
  `voucher_type` ENUM('CASH_PAYMENT', 'CASH_RECEIPT', 'JOURNAL') NOT NULL,
  `date` DATE NOT NULL,
  `sales_staff` VARCHAR(150) DEFAULT NULL,
  `lines` JSON NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `narration` TEXT DEFAULT NULL,
  `created_by` VARCHAR(150) NOT NULL DEFAULT 'System',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_vch_date` (`date`),
  INDEX `idx_vch_type` (`voucher_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 8: invoices
-- Sales Credit, Sales Cash, Purchases, and Returns
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `invoice_no` VARCHAR(50) NOT NULL UNIQUE,
  `invoice_type` ENUM('SALES_CASH', 'SALES_CREDIT', 'PURCHASE_CASH', 'PURCHASE_CREDIT', 'SALES_RETURN', 'PURCHASE_RETURN') NOT NULL,
  `date` DATE NOT NULL,
  `account_name` VARCHAR(255) NOT NULL,
  `sales_staff` VARCHAR(150) DEFAULT NULL,
  `territory` VARCHAR(150) DEFAULT NULL,
  `original_invoice_no` VARCHAR(50) DEFAULT NULL,
  `reason` TEXT DEFAULT NULL,
  `items` JSON NOT NULL,
  `gross_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `discount_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `net_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `remarks` TEXT DEFAULT NULL,
  `created_by` VARCHAR(150) NOT NULL DEFAULT 'System',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_inv_date` (`date`),
  INDEX `idx_inv_type` (`invoice_type`),
  INDEX `idx_inv_account` (`account_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- INITIAL SEED DATA FOR AUGUSTA SEED COMPANY
-- =====================================================================

-- 1. Company Profile
INSERT INTO `company_profile` (`id`, `company_name`, `head_office_address`, `phone`, `mobile`, `email`, `website`, `ntn`, `strn`, `logo_url`, `financial_year`, `invoice_footer`, `report_footer`)
VALUES (
  'default',
  'AUGUSTA SEED COMPANY',
  'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL',
  '03023576036',
  '03023576036',
  'info@augustaseed.com',
  'www.augustaseed.com',
  '3023576-0',
  '30-02-3576-036-01',
  '/logoittehad.png',
  '2026-2027',
  'Seeds sold are verified under Punjab Seed Corporation & FSC&RD certification standards. Goods once sold will not be accepted without valid batch verification.',
  'System-Generated Report by Augusta Seed Company ERP'
) ON DUPLICATE KEY UPDATE `company_name`=VALUES(`company_name`);

-- 2. System Users
INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `mobile`, `role`, `active`, `permissions`)
VALUES 
  ('usr_admin', 'admin', 'System Administrator', 'admin@augustaseed.com', '03023576036', 'ADMIN', 1, '{"canManageUsers":true,"canManageAccounts":true,"canManageProducts":true,"canManageStaff":true,"canManageTerritories":true,"canManageCompany":true,"canCreateVouchers":true,"canCreateInvoices":true,"canViewReports":true,"canEditDelete":true}'),
  ('usr_accountant', 'accountant', 'Muhammad Nasir', 'nasir@augustaseed.com', '03023576036', 'USER', 1, '{"canManageUsers":false,"canManageAccounts":true,"canManageProducts":true,"canManageStaff":false,"canManageTerritories":false,"canManageCompany":false,"canCreateVouchers":true,"canCreateInvoices":true,"canViewReports":true,"canEditDelete":false}')
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`);

-- 3. Territories (Sahiwal Division & Surrounding Zones)
INSERT INTO `territories` (`id`, `territory_code`, `territory_name`, `region`, `assigned_manager`, `status`, `remarks`)
VALUES
  ('tr_1', 'TR-SWL-01', 'Sahiwal Head Office', 'Sahiwal Division', 'Nasir Ali', 'Active', 'Central seed distribution zone'),
  ('tr_2', 'TR-CHW-02', 'Chichawatni Zone', 'Sahiwal Division', 'Tariq Mehmood', 'Active', 'Cotton and wheat grower hub'),
  ('tr_3', 'TR-HRP-03', 'Harappa & Noor Shah', 'Sahiwal Division', 'Zahid Hussain', 'Active', 'Certified seed multiplication zone'),
  ('tr_4', 'TR-OKR-04', 'Okara & Renala Khurd', 'Sahiwal Division', 'Abdul Rehman', 'Active', 'Maize, potato, and wheat seed belt'),
  ('tr_5', 'TR-PKP-05', 'Pakpattan & Arifwala', 'Sahiwal Division', 'Sajid Iqbal', 'Active', 'Basmati rice & cotton belt')
ON DUPLICATE KEY UPDATE `territory_name`=VALUES(`territory_name`);

-- 4. Sales Staff
INSERT INTO `sales_staff` (`id`, `staff_code`, `staff_name`, `father_name`, `mobile`, `whatsapp`, `address`, `city`, `territory`, `joining_date`, `status`, `remarks`)
VALUES
  ('stf_1', 'STF-001', 'Nasir Ali Sahiwal', 'Muhammad Anwar', '03023576036', '03023576036', 'United Farm Road Gulshan-e-Ali By Pass', 'Sahiwal', 'Sahiwal Head Office', '2024-01-01', 'Active', 'Senior Sales & Accounts Officer'),
  ('stf_2', 'STF-002', 'Tariq Mehmood', 'Haji Ghulam Rasool', '03007554433', '03007554433', 'Main Bazar Chichawatni', 'Chichawatni', 'Chichawatni Zone', '2024-03-15', 'Active', 'Field Officer - Seeds'),
  ('stf_3', 'STF-003', 'Zahid Hussain', 'Allah Ditta', '03016644221', '03016644221', 'GT Road Harappa', 'Harappa', 'Harappa & Noor Shah', '2024-06-01', 'Active', 'Area Sales Manager')
ON DUPLICATE KEY UPDATE `staff_name`=VALUES(`staff_name`);

-- 5. Chart of Accounts
INSERT INTO `accounts` (`id`, `code`, `name`, `parent_account`, `account_type`, `sales_staff`, `phone`, `opening_balance`, `opening_balance_type`, `description`, `active`)
VALUES
  ('acc_1', '1001', 'Cash in Hand (Sahiwal Office)', 'Cash & Bank Balances', 'Assets', 'Nasir Ali Sahiwal', '03023576036', 150000.00, 'Dr', 'Primary operational cash vault', 1),
  ('acc_2', '1002', 'Habib Bank Limited (HBL Sahiwal)', 'Cash & Bank Balances', 'Assets', 'Nasir Ali Sahiwal', '0404466221', 850000.00, 'Dr', 'Main company corporate account', 1),
  ('acc_3', '1003', 'MCB Bank Islamic (Sahiwal)', 'Cash & Bank Balances', 'Assets', 'Nasir Ali Sahiwal', '0404466222', 450000.00, 'Dr', 'Seed vendor clearing account', 1),
  ('acc_4', '1004', 'Sundry Debtors / Growers (Receivables)', 'Current Assets', 'Assets', 'Nasir Ali Sahiwal', '03023576036', 320000.00, 'Dr', 'Receivables from seed dealers & farmers', 1),
  ('acc_5', '1005', 'Stock in Trade (Certified Seeds)', 'Inventories', 'Assets', 'Nasir Ali Sahiwal', '03023576036', 1250000.00, 'Dr', 'Certified seed stock in godown', 1),
  ('acc_6', '2001', 'Sundry Creditors (Growers / Seed Farms)', 'Current Liabilities', 'Liabilities', 'Nasir Ali Sahiwal', '03023576036', 180000.00, 'Cr', 'Payables to registered seed seed producers', 1),
  ('acc_7', '3001', 'Capital Account (Owners Equity)', 'Equity & Reserves', 'Equity', NULL, '03023576036', 2500000.00, 'Cr', 'Owner investment & seed plant equity', 1),
  ('acc_8', '4001', 'Seed Sales Revenue', 'Operating Revenue', 'Revenue', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Cr', 'Revenue from certified seed sales', 1),
  ('acc_9', '5001', 'Seed Procurement Cost', 'Cost of Sales', 'Expenses', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Dr', 'Raw seed acquisition from growers', 1),
  ('acc_10', '5002', 'Seed Processing & Grading Expenses', 'Processing Costs', 'Expenses', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Dr', 'Seed cleaner, gravity separator & chemical treatment', 1),
  ('acc_11', '5003', 'Packaging & Bag Printing Expenses', 'Processing Costs', 'Expenses', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Dr', 'PP Woven bags, tags, and certification seals', 1),
  ('acc_12', '5004', 'Staff Salaries & Field Allowances', 'Operating Expenses', 'Expenses', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Dr', 'Monthly field officer salaries and fuel', 1),
  ('acc_13', '5005', 'Godown Rent & Warehouse Electric Bill', 'Operating Expenses', 'Expenses', 'Nasir Ali Sahiwal', '03023576036', 0.00, 'Dr', 'United Farm Road seed godown rent', 1)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- 6. Product Master (Augusta Certified Seed Varieties)
INSERT INTO `products` (`id`, `product_code`, `product_name`, `variety`, `unit`, `pack_size`, `purchase_rate`, `sale_rate`, `current_stock`, `minimum_stock`, `lot_no`, `status`, `remarks`)
VALUES
  ('p_1', 'SD-WHT-01', 'Wheat Seed Akbar 2019 Certified', 'Akbar 2019', 'Bag', '50kg', 4200.00, 4800.00, 450.00, 50.00, 'LOT-AKB-2026', 'Active', 'High yielding rust resistant wheat seed'),
  ('p_2', 'SD-WHT-02', 'Wheat Seed Dilkash 2020 Certified', 'Dilkash 2020', 'Bag', '50kg', 4300.00, 4900.00, 380.00, 50.00, 'LOT-DLK-2026', 'Active', 'Premium grain quality wheat seed'),
  ('p_3', 'SD-COT-03', 'Cotton Seed Triple Gene Bt-886', 'Bt-886', 'Bag', '40kg', 7500.00, 8500.00, 220.00, 30.00, 'LOT-COT-886', 'Active', 'Bollworm and pink bollworm tolerant'),
  ('p_4', 'SD-COT-04', 'Cotton Seed Super BS-15 Hybrid', 'BS-15', 'Bag', '40kg', 7800.00, 8900.00, 180.00, 25.00, 'LOT-BS-15-26', 'Active', 'Early maturing heat tolerant variety'),
  ('p_5', 'SD-MAZ-05', 'Hybrid Corn / Maize Augusta-999', 'Augusta-999', 'Bag', '20kg', 9500.00, 11000.00, 150.00, 20.00, 'LOT-MZ-999', 'Active', 'High fodder and grain yield spring/autumn corn'),
  ('p_6', 'SD-RIC-06', 'Rice Seed Kainat 1121 Steam Basmati', 'Kainat 1121', 'Bag', '25kg', 3800.00, 4400.00, 300.00, 40.00, 'LOT-RC-1121', 'Active', 'Extra long grain export quality basmati seed')
ON DUPLICATE KEY UPDATE `product_name`=VALUES(`product_name`);
