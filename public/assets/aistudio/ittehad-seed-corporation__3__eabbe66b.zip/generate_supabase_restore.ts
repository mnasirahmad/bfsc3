import fs from 'fs';
import path from 'path';

const jsonPath = path.resolve(process.cwd(), 'public/assets/aistudio/vch_0558a3b3.json');
const outSqlPath = path.resolve(process.cwd(), 'supabase_restore_vouchers.sql');

try {
  let raw = fs.readFileSync(jsonPath, 'utf-8').trim();
  if (raw.endsWith(',')) {
    raw = raw.slice(0, -1);
  }
  if (!raw.startsWith('{')) {
    if (!raw.startsWith('"vouchers"')) {
      raw = '{"vouchers": ' + raw + '}';
    } else {
      raw = '{' + raw + '}';
    }
  }

  const data = JSON.parse(raw);
  const vouchers = data.vouchers || [];

  let sql = `-- ========================================================\n`;
  sql += `-- Restore Vouchers into Supabase / PostgreSQL 'vouchers' table\n`;
  sql += `-- ========================================================\n\n`;

  vouchers.forEach((v: any) => {
    const id = v.id || `vch_${Date.now()}_${Math.floor(Math.random()*1000)}`;
    const voucherNo = (v.voucherNo || '').replace(/'/g, "''");
    const voucherType = v.voucherType || 'JOURNAL';
    const date = v.date || new Date().toISOString().split('T')[0];
    const salesStaff = v.salesStaff ? `'${v.salesStaff.replace(/'/g, "''")}'` : 'NULL';
    const lines = JSON.stringify(v.lines || []).replace(/'/g, "''");
    const totalAmount = Number(v.totalAmount || 0);
    const narration = v.narration ? `'${v.narration.replace(/'/g, "''")}'` : 'NULL';
    const createdBy = v.createdBy ? `'${v.createdBy.replace(/'/g, "''")}'` : `'System Administrator'`;
    const createdAt = v.createdAt ? `'${v.createdAt.replace('T', ' ').replace('Z', '')}'` : 'NOW()';

    sql += `INSERT INTO vouchers (id, voucher_no, voucher_type, date, sales_staff, lines, total_amount, narration, created_by, created_at) \n`;
    sql += `VALUES ('${id}', '${voucherNo}', '${voucherType}', '${date}', ${salesStaff}, '${lines}', ${totalAmount}, ${narration}, ${createdBy}, ${createdAt})\n`;
    sql += `ON CONFLICT (id) DO UPDATE SET voucher_no = EXCLUDED.voucher_no, lines = EXCLUDED.lines, total_amount = EXCLUDED.total_amount;\n\n`;
  });

  fs.writeFileSync(outSqlPath, sql, 'utf-8');
  console.log('Successfully generated Supabase restore SQL script.');
} catch (err) {
  console.error('Error generating Supabase restore SQL:', err);
}
