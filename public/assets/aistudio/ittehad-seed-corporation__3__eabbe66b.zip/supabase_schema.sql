-- ============================================================
-- Ittehad Seed Corporation ERP - Supabase PostgreSQL Schema
-- Compatible with Supabase SQL Editor / PostgreSQL 13+
-- Includes DATE and TIMESTAMPTZ columns with performance indexes
-- ============================================================

-- 1. Company Profile Table
CREATE TABLE IF NOT EXISTS company_profile (
  id VARCHAR(50) PRIMARY KEY,
  company_name VARCHAR(255) NOT NULL,
  head_office_address TEXT,
  phone VARCHAR(100),
  mobile VARCHAR(100),
  email VARCHAR(100),
  website VARCHAR(100),
  ntn VARCHAR(100),
  strn VARCHAR(100),
  logo_url TEXT,
  financial_year VARCHAR(50) DEFAULT '2026-2027',
  invoice_footer TEXT,
  report_footer TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Users Table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(50) PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  full_name VARCHAR(255) NOT NULL,
  email VARCHAR(150),
  mobile VARCHAR(100),
  role VARCHAR(50) NOT NULL DEFAULT 'USER',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  permissions TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Accounts Table
CREATE TABLE IF NOT EXISTS accounts (
  id VARCHAR(50) PRIMARY KEY,
  code VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  parent_account VARCHAR(255),
  account_type TEXT NOT NULL CHECK (account_type IN ('Assets','Liabilities','Equity','Revenue','Expenses','General Ledgers','Cash/Banks')),
  sales_staff VARCHAR(255),
  phone VARCHAR(100),
  opening_balance NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  opening_balance_type TEXT NOT NULL DEFAULT 'Dr' CHECK (opening_balance_type IN ('Dr','Cr')),
  description TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts(account_type);

-- 4. Sales Staff Table
CREATE TABLE IF NOT EXISTS sales_staff (
  id VARCHAR(50) PRIMARY KEY,
  staff_code VARCHAR(50) NOT NULL UNIQUE,
  staff_name VARCHAR(255) NOT NULL,
  father_name VARCHAR(255),
  mobile VARCHAR(100),
  whatsapp VARCHAR(100),
  address TEXT,
  city VARCHAR(100),
  territory VARCHAR(150),
  joining_date DATE,
  status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive')),
  remarks TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_staff_joining_date ON sales_staff(joining_date);

-- 5. Territories Table
CREATE TABLE IF NOT EXISTS territories (
  id VARCHAR(50) PRIMARY KEY,
  territory_code VARCHAR(50) NOT NULL UNIQUE,
  territory_name VARCHAR(255) NOT NULL,
  city VARCHAR(100),
  district VARCHAR(100),
  description TEXT,
  status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Products Table
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(50) PRIMARY KEY,
  product_code VARCHAR(50) NOT NULL UNIQUE,
  product_name VARCHAR(255) NOT NULL,
  category VARCHAR(100) DEFAULT 'Seeds',
  variety VARCHAR(100),
  unit VARCHAR(50) DEFAULT 'Kgs',
  pack_size VARCHAR(50) DEFAULT 'Single',
  purchase_rate NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  sale_rate NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  opening_stock NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  opening_stock_rate NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  minimum_stock NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  description TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Vouchers Table
CREATE TABLE IF NOT EXISTS vouchers (
  id VARCHAR(50) PRIMARY KEY,
  voucher_no VARCHAR(100) NOT NULL UNIQUE,
  voucher_type TEXT NOT NULL CHECK (voucher_type IN ('CASH_PAYMENT','CASH_RECEIPT','JOURNAL')),
  date DATE NOT NULL,
  sales_staff VARCHAR(255),
  lines TEXT NOT NULL,
  total_amount NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  narration TEXT,
  created_by VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vouchers_date ON vouchers(date);
CREATE INDEX IF NOT EXISTS idx_vouchers_type ON vouchers(voucher_type);

-- 8. Invoices Table
CREATE TABLE IF NOT EXISTS invoices (
  id VARCHAR(50) PRIMARY KEY,
  invoice_no VARCHAR(100) NOT NULL UNIQUE,
  invoice_type TEXT NOT NULL,
  date DATE NOT NULL,
  account_name VARCHAR(255) NOT NULL,
  sales_staff VARCHAR(255),
  territory VARCHAR(150),
  original_invoice_no VARCHAR(100),
  reason TEXT,
  items TEXT NOT NULL,
  gross_total NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  discount_total NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  net_total NUMERIC(15,2) NOT NULL DEFAULT 0.00,
  remarks TEXT,
  created_by VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(date);
CREATE INDEX IF NOT EXISTS idx_invoices_type ON invoices(invoice_type);
CREATE INDEX IF NOT EXISTS idx_invoices_account ON invoices(account_name);

-- 9. Initial Default Data Seeding
INSERT INTO company_profile (id, company_name, head_office_address, phone, mobile, email, website, ntn, strn, logo_url, financial_year, invoice_footer, report_footer)
VALUES ('default', 'Ittehad Seed Corporation', 'Qaboola Road Arifwala', '03216533233', '03216533233', 'info@ittehadseed.com', 'www.ittehadseed.com', '3216533-2', '32-16-5332-330-01', '/logoittehad.png', '2026-2027', 'Quality Seeds Guaranteed. Goods once sold will not be returned without warranty inspection.', 'Computer generated official document. Ittehad Seed Corporation Arifwala.')
ON CONFLICT (id) DO UPDATE SET company_name = EXCLUDED.company_name;

INSERT INTO users (id, username, full_name, email, mobile, role, active, permissions)
VALUES ('usr_admin_01', 'admin', 'System Administrator', 'admin@ittehadseed.com', '03216533233', 'ADMIN', TRUE, '{"canManageUsers": true, "canManageAccounts": true, "canManageProducts": true, "canManageStaff": true, "canManageTerritories": true, "canManageCompany": true, "canCreateVouchers": true, "canCreateInvoices": true, "canViewReports": true, "canEditDelete": true}')
ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name;
