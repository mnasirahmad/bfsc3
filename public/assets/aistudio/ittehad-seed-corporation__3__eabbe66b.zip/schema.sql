-- ============================================================
-- Ittehad Seed Corporation ERP - Database Schema
-- Compatible with MySQL 5.7+, MySQL 8.0+, and MariaDB 10.3+
-- Includes DATE and TIMESTAMP columns with performance indexes
-- ============================================================

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ------------------------------------------------------------
-- Table 1: company_profile
-- Stores company details, fiscal period, and audit timestamp
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `company_profile` (
  `id` VARCHAR(50) NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `head_office_address` TEXT NULL,
  `phone` VARCHAR(100) NULL,
  `mobile` VARCHAR(100) NULL,
  `email` VARCHAR(100) NULL,
  `website` VARCHAR(100) NULL,
  `ntn` VARCHAR(100) NULL,
  `strn` VARCHAR(100) NULL,
  `logo_url` LONGTEXT NULL,
  `financial_year` VARCHAR(50) DEFAULT '2026-2027',
  `invoice_footer` TEXT NULL,
  `report_footer` TEXT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 2: users
-- Stores ERP user credentials, roles, permissions, and creation date
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `full_name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(150) NULL,
  `mobile` VARCHAR(100) NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'USER',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `permissions` LONGTEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_users_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 3: accounts
-- Chart of accounts (Ledgers, Cash, Banks, Farmers, Suppliers)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` VARCHAR(50) NOT NULL,
  `code` VARCHAR(50) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `parent_account` VARCHAR(255) NULL,
  `account_type` ENUM('Assets','Liabilities','Equity','Revenue','Expenses','General Ledgers') NOT NULL,
  `sales_staff` VARCHAR(255) NULL,
  `phone` VARCHAR(100) NULL,
  `opening_balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_balance_type` ENUM('Dr','Cr') NOT NULL DEFAULT 'Dr',
  `description` TEXT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_accounts_code` (`code`),
  KEY `idx_accounts_type` (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 4: sales_staff
-- Sales team members, contact details, and joining date
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales_staff` (
  `id` VARCHAR(50) NOT NULL,
  `staff_code` VARCHAR(50) NOT NULL,
  `staff_name` VARCHAR(255) NOT NULL,
  `father_name` VARCHAR(255) NULL,
  `mobile` VARCHAR(100) NULL,
  `whatsapp` VARCHAR(100) NULL,
  `address` TEXT NULL,
  `city` VARCHAR(100) NULL,
  `territory` VARCHAR(150) NULL,
  `joining_date` DATE NULL,
  `status` ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  `remarks` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_staff_code` (`staff_code`),
  KEY `idx_staff_joining_date` (`joining_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 5: territories
-- Marketing & distribution regions/cities
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `territories` (
  `id` VARCHAR(50) NOT NULL,
  `territory_code` VARCHAR(50) NOT NULL,
  `territory_name` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100) NULL,
  `district` VARCHAR(100) NULL,
  `description` TEXT NULL,
  `status` ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_territory_code` (`territory_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 6: products
-- Seed varieties, pricing, units, and inventory tracking
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(50) NOT NULL,
  `product_code` VARCHAR(50) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NULL DEFAULT 'Seeds',
  `variety` VARCHAR(100) NULL,
  `unit` VARCHAR(50) NULL DEFAULT 'Kgs',
  `pack_size` VARCHAR(50) NULL DEFAULT 'Single',
  `purchase_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `sale_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_stock_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `minimum_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `description` TEXT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 7: vouchers
-- Cash Payment (CPV), Cash Receipt (CRV), and Journal Vouchers (JV)
-- Contains transaction DATE with index for fast date-range filtering
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `vouchers` (
  `id` VARCHAR(50) NOT NULL,
  `voucher_no` VARCHAR(100) NOT NULL,
  `voucher_type` ENUM('CASH_PAYMENT','CASH_RECEIPT','JOURNAL') NOT NULL,
  `date` DATE NOT NULL,
  `sales_staff` VARCHAR(255) NULL,
  `lines` LONGTEXT NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `narration` TEXT NULL,
  `created_by` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_voucher_no` (`voucher_no`),
  KEY `idx_voucher_date` (`date`),
  KEY `idx_voucher_type` (`voucher_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table 8: invoices
-- Sales invoices, Purchase bills, and Returns
-- Contains transaction DATE with index for fast date-range filtering
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` VARCHAR(50) NOT NULL,
  `invoice_no` VARCHAR(100) NOT NULL,
  `invoice_type` ENUM('SALES_CREDIT','SALES_CASH','PURCHASE_CREDIT','PURCHASE_CASH','SALES_RETURN','PURCHASE_RETURN') NOT NULL,
  `date` DATE NOT NULL,
  `account_name` VARCHAR(255) NOT NULL,
  `sales_staff` VARCHAR(255) NULL,
  `territory` VARCHAR(150) NULL,
  `original_invoice_no` VARCHAR(100) NULL,
  `reason` TEXT NULL,
  `items` LONGTEXT NOT NULL,
  `gross_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `discount_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `net_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `remarks` TEXT NULL,
  `created_by` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_invoice_no` (`invoice_no`),
  KEY `idx_invoice_date` (`date`),
  KEY `idx_invoice_type` (`invoice_type`),
  KEY `idx_invoice_account` (`account_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Initial Default Profile & Admin Seed (safe with ON DUPLICATE KEY)
-- ------------------------------------------------------------
INSERT INTO `company_profile` (`id`, `company_name`, `head_office_address`, `phone`, `mobile`, `email`, `website`, `ntn`, `strn`, `logo_url`, `financial_year`, `invoice_footer`, `report_footer`)
VALUES ('default', 'Ittehad Seed Corporation', 'Qaboola Road Arifwala', '03216533233', '03216533233', 'info@ittehadseed.com', 'www.ittehadseed.com', '3216533-2', '32-16-5332-330-01', '/logoittehad.png', '2026-2027', 'Quality Seeds Guaranteed. Goods once sold will not be returned without warranty inspection.', 'Computer generated official document. Ittehad Seed Corporation Arifwala.')
ON DUPLICATE KEY UPDATE `company_name` = VALUES(`company_name`);

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `mobile`, `role`, `active`, `permissions`)
VALUES ('usr_admin_01', 'admin', 'System Administrator', 'admin@ittehadseed.com', '03216533233', 'ADMIN', 1, '{"canManageUsers": true, "canManageAccounts": true, "canManageProducts": true, "canManageStaff": true, "canManageTerritories": true, "canManageCompany": true, "canCreateVouchers": true, "canCreateInvoices": true, "canViewReports": true, "canEditDelete": true}')
ON DUPLICATE KEY UPDATE `full_name` = VALUES(`full_name`);

SET foreign_key_checks = 1;
