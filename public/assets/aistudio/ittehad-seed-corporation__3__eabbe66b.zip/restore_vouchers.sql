-- ========================================================
-- Restore Vouchers into MySQL Table 'vouchers'
-- ========================================================

SET NAMES utf8mb4;
USE `ittehadseed-35303437efb4`;

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663761941', 'JOU-6321', 'JOURNAL', '2026-10-22', NULL, '[{"accountId":"acc-452492","accountName":"KISSAN C/S","narration":"JV.JOU-6321 KISSAN C/S from. CASH ENTRY ITTEHAD ZARI","debit":212800,"credit":0},{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-6321 CASH ENTRY ITTEHAD ZARI from. KISSAN C/S","debit":0,"credit":212800}]', 212800, 'JV.JOU-6321 KISSAN C/S from. CASH ENTRY ITTEHAD ZARI | JV.JOU-6321 CASH ENTRY ITTEHAD ZARI from. KISSAN C/S', 'System Administrator', '2026-10-22 10:09:21.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663702325', 'JOU-7467', 'JOURNAL', '2026-10-22', NULL, '[{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-7467 CASH ENTRY ITTEHAD ZARI from. NAYA SAWERA ADDA RANG SHAH","debit":60000,"credit":0},{"accountId":"acc-452115","accountName":"NAYA SAWERA ADDA RANG SHAH","description":"JV.JOU-7467 NAYA SAWERA ADDA RANG SHAH from. CASH ENTRY ITTEHAD ZARI","debit":0,"credit":60000}]', 60000, 'JV.JOU-7467 CASH ENTRY ITTEHAD ZARI from. NAYA SAWERA ADDA RANG SHAH | JV.JOU-7467 NAYA SAWERA ADDA RANG SHAH from. CASH ENTRY ITTEHAD ZARI', 'System Administrator', '2026-10-22 10:08:22.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663659853', 'JOU-8582', 'JOURNAL', '2026-10-22', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-8582 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA","debit":54300,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-8582 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":54300}]', 54300, 'JV.JOU-8582 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA | JV.JOU-8582 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-10-22 10:07:39.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663577350', 'CAS-7091', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.NEW ITTEHAD CORPORATION","debit":15820,"credit":0},{"accountId":"acc-451493","accountName":"NEW ITTEHAD CORPORATION","description":"from.NEW ITTEHAD CORPORATION","debit":0,"credit":15820}]', 15820, 'from.NEW ITTEHAD CORPORATION', 'System Administrator', '2026-10-22 10:06:17.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663549622', 'CAS-2100', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.HBL NEW A/C LARI ADDA","debit":284750,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"from.HBL NEW A/C LARI ADDA","debit":0,"credit":284750}]', 284750, 'from.HBL NEW A/C LARI ADDA', 'System Administrator', '2026-10-22 10:05:49.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663518239', 'CAS-5193', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.PAK AFGHOI MIS. EXP","debit":58180,"credit":0},{"accountId":"acc-451584","accountName":"PAK AFGHOI MIS. EXP","description":"from.PAK AFGHOI MIS. EXP","debit":0,"credit":58180}]', 58180, 'from.PAK AFGHOI MIS. EXP', 'System Administrator', '2026-10-22 10:05:18.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663479655', 'CAS-5532', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.CASH ENTRY ITTEHAD ZARI","debit":1500000,"credit":0},{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"from.CASH ENTRY ITTEHAD ZARI","debit":0,"credit":1500000}]', 1500000, 'from.CASH ENTRY ITTEHAD ZARI', 'System Administrator', '2026-10-22 10:04:39.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663454895', 'CAS-4417', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.WHEAT 2026","debit":4000,"credit":0},{"accountId":"acc-452568","accountName":"WHEAT 2026","description":"from.WHEAT 2026","debit":0,"credit":4000}]', 4000, 'from.WHEAT 2026', 'System Administrator', '2026-10-22 10:04:14.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663431103', 'CAS-9910', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.TAG CONTRACTOR FACTORY","debit":120000,"credit":0},{"accountId":"acc-451303","accountName":"TAG CONTRACTOR FACTORY","description":"from.TAG CONTRACTOR FACTORY","debit":0,"credit":120000}]', 120000, 'from.TAG CONTRACTOR FACTORY', 'System Administrator', '2026-10-22 10:03:51.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663386696', 'CAS-6447', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":141100,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":141100}]', 141100, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:03:06.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663366321', 'CAS-6829', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":141830,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":141830}]', 141830, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:02:46.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663337848', 'CAS-2248', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":82800,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":82800}]', 82800, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:02:17.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663322256', 'CAS-2882', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":54900,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":54900}]', 54900, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:02:02.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663306913', 'CAS-1683', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":54250,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":54250}]', 54250, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:01:46.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663285954', 'CAS-7967', 'CASH_RECEIPT', '2026-10-22', NULL, '[{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":131175,"credit":0},{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"from.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":131175}]', 131175, 'from.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 10:01:25.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057457933', 'JOU-9830', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-9830 ITTEHAD FOOD INDUSTRIES from. AK TRADERS","debit":1288000,"credit":0},{"accountId":"acc-452431","accountName":"AK TRADERS","description":"JV.JOU-9830 AK TRADERS from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":1288000}]', 1288000, 'JV.JOU-9830 ITTEHAD FOOD INDUSTRIES from. AK TRADERS | JV.JOU-9830 AK TRADERS from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-26 09:17:37.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057416213', 'JOU-2240', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-451864","accountName":"W.HOLDING TAX","description":"JV.JOU-2240 W.HOLDING TAX from. FASIAL BANK 118","debit":1811,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-2240 FASIAL BANK 118 from. W.HOLDING TAX","debit":0,"credit":1811}]', 1811, 'JV.JOU-2240 W.HOLDING TAX from. FASIAL BANK 118 | JV.JOU-2240 FASIAL BANK 118 from. W.HOLDING TAX', 'System Administrator', '2026-07-26 09:16:56.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057373845', 'JOU-8474', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-430813","accountName":"FUEL EXPENCES","description":"JV.JOU-8474 FUEL EXPENCES from. FASIAL BANK 118","debit":11097,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-8474 FASIAL BANK 118 from. FUEL EXPENCES","debit":0,"credit":11097}]', 11097, 'JV.JOU-8474 FUEL EXPENCES from. FASIAL BANK 118 | JV.JOU-8474 FASIAL BANK 118 from. FUEL EXPENCES', 'System Administrator', '2026-07-26 09:16:13.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057341822', 'JOU-8185', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-451172","accountName":"HOME EXP","description":"JV.JOU-8185 HOME EXP from. FASIAL BANK 118","debit":40000,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-8185 FASIAL BANK 118 from. HOME EXP","debit":0,"credit":40000}]', 40000, 'JV.JOU-8185 HOME EXP from. FASIAL BANK 118 | JV.JOU-8185 FASIAL BANK 118 from. HOME EXP', 'System Administrator', '2026-07-26 09:15:41.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057310278', 'JOU-9381', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-451172","accountName":"HOME EXP","description":"JV.JOU-9381 HOME EXP from. FASIAL BANK 118","debit":128300,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-9381 FASIAL BANK 118 from. HOME EXP","debit":0,"credit":128300}]', 128300, 'JV.JOU-9381 HOME EXP from. FASIAL BANK 118 | JV.JOU-9381 FASIAL BANK 118 from. HOME EXP', 'System Administrator', '2026-07-26 09:15:10.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057283878', 'JOU-6013', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-430800","accountName":"ENTERTAINMENT A/C","description":"JV.JOU-6013 ENTERTAINMENT A/C from. FASIAL BANK 118","debit":35706,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-6013 FASIAL BANK 118 from. ENTERTAINMENT A/C","debit":0,"credit":35706}]', 35706, 'JV.JOU-6013 ENTERTAINMENT A/C from. FASIAL BANK 118 | JV.JOU-6013 FASIAL BANK 118 from. ENTERTAINMENT A/C', 'System Administrator', '2026-07-26 09:14:43.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057242071', 'JOU-7888', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-452035","accountName":"CHARIETY A/C","description":"JV.JOU-7888 CHARIETY A/C from. FASIAL BANK 118","debit":25000,"credit":0},{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-7888 FASIAL BANK 118 from. CHARIETY A/C","debit":0,"credit":25000}]', 25000, 'JV.JOU-7888 CHARIETY A/C from. FASIAL BANK 118 | JV.JOU-7888 FASIAL BANK 118 from. CHARIETY A/C', 'System Administrator', '2026-07-26 09:14:02.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1785057198776', 'JOU-4846', 'JOURNAL', '2026-07-26', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-4846 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA","debit":2500000,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-4846 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":2500000}]', 2500000, 'JV.JOU-4846 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA | JV.JOU-4846 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-26 09:13:18.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784998216532', 'JOU-2141', 'JOURNAL', '2026-07-25', NULL, '[{"accountId":"acc-451864","accountName":"W.HOLDING TAX","description":"JV.JOU-2141 W.HOLDING TAX from. HBL NEW A/C LARI ADDA","debit":192,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-2141 HBL NEW A/C LARI ADDA from. W.HOLDING TAX","debit":0,"credit":192}]', 192, 'JV.JOU-2141 W.HOLDING TAX from. HBL NEW A/C LARI ADDA | JV.JOU-2141 HBL NEW A/C LARI ADDA from. W.HOLDING TAX', 'System Administrator', '2026-07-25 16:50:16.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784998178612', 'JOU-2773', 'JOURNAL', '2026-07-25', NULL, '[{"accountId":"acc-452018","accountName":"RAMSHA KHALID","description":"JV.JOU-2773 RAMSHA KHALID from. ITTEHAD FOOD INDUSTRIES","debit":50000,"credit":0},{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-2773 ITTEHAD FOOD INDUSTRIES from. RAMSHA KHALID","debit":0,"credit":50000}]', 50000, 'JV.JOU-2773 RAMSHA KHALID from. ITTEHAD FOOD INDUSTRIES | JV.JOU-2773 ITTEHAD FOOD INDUSTRIES from. RAMSHA KHALID', 'System Administrator', '2026-07-25 16:49:38.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784998086829', 'JOU-3945', 'JOURNAL', '2026-07-25', NULL, '[{"accountId":"acc-410809","accountName":"FASIAL BANK 118","description":"JV.JOU-3945 FASIAL BANK 118 from. RAMSHA KHALID","debit":150000,"credit":0},{"accountId":"acc-452018","accountName":"RAMSHA KHALID","description":"JV.JOU-3945 RAMSHA KHALID from. FASIAL BANK 118","debit":0,"credit":150000}]', 150000, 'JV.JOU-3945 FASIAL BANK 118 from. RAMSHA KHALID | JV.JOU-3945 RAMSHA KHALID from. FASIAL BANK 118', 'System Administrator', '2026-07-25 16:48:06.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784998049829', 'JOU-7142', 'JOURNAL', '2026-07-25', NULL, '[{"accountId":"acc-452929","accountName":"AGRI FARM 2027","description":"JV.JOU-7142 AGRI FARM 2027 from. ITTEHAD FOOD INDUSTRIES","debit":24415,"credit":0},{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-7142 ITTEHAD FOOD INDUSTRIES from. AGRI FARM 2027","debit":0,"credit":24415}]', 24415, 'JV.JOU-7142 AGRI FARM 2027 from. ITTEHAD FOOD INDUSTRIES | JV.JOU-7142 ITTEHAD FOOD INDUSTRIES from. AGRI FARM 2027', 'System Administrator', '2026-07-25 16:47:29.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784997955396', 'JOU-8777', 'JOURNAL', '2026-07-25', NULL, '[{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-8777 HBL NEW A/C LARI ADDA from. NAYA SAWERA OKARA","debit":550000,"credit":0},{"accountId":"acc-452642","accountName":"NAYA SAWERA OKARA","description":"JV.JOU-8777 NAYA SAWERA OKARA from. HBL NEW A/C LARI ADDA","debit":0,"credit":550000}]', 550000, 'JV.JOU-8777 HBL NEW A/C LARI ADDA from. NAYA SAWERA OKARA | JV.JOU-8777 NAYA SAWERA OKARA from. HBL NEW A/C LARI ADDA', 'System Administrator', '2026-07-25 16:45:55.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821643128', 'JOU-2030', 'JOURNAL', '2026-07-24', NULL, '[{"accountId":"acc-410846","accountName":"CF PLEDGE 12187","description":"JV.JOU-2030 CF PLEDGE 12187 from. ITTEHAD FOOD INDUSTRIES","debit":3000000,"credit":0},{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-2030 ITTEHAD FOOD INDUSTRIES from. CF PLEDGE 12187","debit":0,"credit":3000000}]', 3000000, 'JV.JOU-2030 CF PLEDGE 12187 from. ITTEHAD FOOD INDUSTRIES | JV.JOU-2030 ITTEHAD FOOD INDUSTRIES from. CF PLEDGE 12187', 'System Administrator', '2026-07-23 15:47:23.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821602089', 'JOU-6029', 'JOURNAL', '2026-07-24', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-6029 ITTEHAD FOOD INDUSTRIES from. ALLAH WALA TRADERS","debit":1500000,"credit":0},{"accountId":"acc-452474","accountName":"ALLAH WALA TRADERS","description":"JV.JOU-6029 ALLAH WALA TRADERS from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":1500000}]', 1500000, 'JV.JOU-6029 ITTEHAD FOOD INDUSTRIES from. ALLAH WALA TRADERS | JV.JOU-6029 ALLAH WALA TRADERS from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-23 15:46:42.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663254161', 'CAS-6396', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430813","accountName":"FUEL EXPENCES","description":"Cash paid to.FUEL EXPENCES","debit":1500,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.FUEL EXPENCES","debit":0,"credit":1500}]', 1500, 'Cash paid to.FUEL EXPENCES', 'System Administrator', '2026-10-22 10:00:54.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663235881', 'CAS-6959', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430801","accountName":"MISCELLANEOUS A/C","description":"Cash paid to.MISCELLANEOUS A/C","debit":1230,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MISCELLANEOUS A/C","debit":0,"credit":1230}]', 1230, 'Cash paid to.MISCELLANEOUS A/C', 'System Administrator', '2026-10-22 10:00:35.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663195531', 'CAS-2506', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451193","accountName":"ZAKAT A/C","description":"Cash paid to.ZAKAT A/C","debit":1500,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ZAKAT A/C","debit":0,"credit":1500}]', 1500, 'Cash paid to.ZAKAT A/C', 'System Administrator', '2026-10-22 09:59:55.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663173617', 'CAS-6641', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430800","accountName":"ENTERTAINMENT A/C","description":"Cash paid to.ENTERTAINMENT A/C","debit":5590,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ENTERTAINMENT A/C","debit":0,"credit":5590}]', 5590, 'Cash paid to.ENTERTAINMENT A/C', 'System Administrator', '2026-10-22 09:59:33.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663155337', 'CAS-1986', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451172","accountName":"HOME EXP","description":"Cash paid to.HOME EXP","debit":6000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.HOME EXP","debit":0,"credit":6000}]', 6000, 'Cash paid to.HOME EXP', 'System Administrator', '2026-10-22 09:59:15.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663138745', 'CAS-9936', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430801","accountName":"MISCELLANEOUS A/C","description":"Cash paid to.MISCELLANEOUS A/C","debit":5000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MISCELLANEOUS A/C","debit":0,"credit":5000}]', 5000, 'Cash paid to.MISCELLANEOUS A/C', 'System Administrator', '2026-10-22 09:58:58.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663093345', 'CAS-2215', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430800","accountName":"ENTERTAINMENT A/C","description":"Cash paid to.ENTERTAINMENT A/C","debit":10000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ENTERTAINMENT A/C","debit":0,"credit":10000}]', 10000, 'Cash paid to.ENTERTAINMENT A/C', 'System Administrator', '2026-10-22 09:58:13.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663037226', 'CAS-6272', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"Cash paid to.ITTEHAD FOOD INDUSTRIES","debit":1140952,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ITTEHAD FOOD INDUSTRIES","debit":0,"credit":1140952}]', 1140952, 'Cash paid to.ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-10-22 09:57:17.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792663011074', 'CAS-5404', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-452841","accountName":"ITTEHAD COLD HAVEN STORAGE","description":"Cash paid to.ITTEHAD COLD HAVEN STORAGE","debit":238760,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ITTEHAD COLD HAVEN STORAGE","debit":0,"credit":238760}]', 238760, 'Cash paid to.ITTEHAD COLD HAVEN STORAGE', 'System Administrator', '2026-10-22 09:56:51.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662979475', 'CAS-6466', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451741","accountName":"SEED DISCOUNT/RETURNED","description":"Cash paid to.SEED DISCOUNT/RETURNED","debit":5000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.SEED DISCOUNT/RETURNED","debit":0,"credit":5000}]', 5000, 'Cash paid to.SEED DISCOUNT/RETURNED', 'System Administrator', '2026-10-22 09:56:19.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662962211', 'CAS-1146', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451172","accountName":"HOME EXP","description":"Cash paid to.HOME EXP","debit":20000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.HOME EXP","debit":0,"credit":20000}]', 20000, 'Cash paid to.HOME EXP', 'System Administrator', '2026-10-22 09:56:02.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662941819', 'CAS-3187', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430800","accountName":"ENTERTAINMENT A/C","description":"Cash paid to.ENTERTAINMENT A/C","debit":13910,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ENTERTAINMENT A/C","debit":0,"credit":13910}]', 13910, 'Cash paid to.ENTERTAINMENT A/C', 'System Administrator', '2026-10-22 09:55:41.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662916315', 'CAS-2793', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451193","accountName":"ZAKAT A/C","description":"Cash paid to.ZAKAT A/C","debit":3500,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ZAKAT A/C","debit":0,"credit":3500}]', 3500, 'Cash paid to.ZAKAT A/C', 'System Administrator', '2026-10-22 09:55:16.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662883095', 'CAS-9848', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430801","accountName":"MISCELLANEOUS A/C","description":"Cash paid to.MISCELLANEOUS A/C","debit":2963,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MISCELLANEOUS A/C","debit":0,"credit":2963}]', 2963, 'Cash paid to.MISCELLANEOUS A/C', 'System Administrator', '2026-10-22 09:54:43.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1792662864138', 'CAS-8749', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451172","accountName":"HOME EXP","description":"Cash paid to.HOME EXP","debit":8000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.HOME EXP","debit":0,"credit":8000}]', 8000, 'Cash paid to.HOME EXP', 'System Administrator', '2026-10-22 09:54:24.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821473898', 'JOU-9992', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-452835","accountName":"AGRI RESEARCH FARM","description":"JV.JOU-9992 AGRI RESEARCH FARM from. CASH ENTRY ITTEHAD ZARI","debit":1400,"credit":0},{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-9992 CASH ENTRY ITTEHAD ZARI from. AGRI RESEARCH FARM","debit":0,"credit":1400}]', 1400, 'JV.JOU-9992 AGRI RESEARCH FARM from. CASH ENTRY ITTEHAD ZARI | JV.JOU-9992 CASH ENTRY ITTEHAD ZARI from. AGRI RESEARCH FARM', 'System Administrator', '2026-07-23 15:44:33.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821434130', 'JOU-5997', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-452878","accountName":"ISC CROP SCIENCES","description":"JV.JOU-5997 ISC CROP SCIENCES from. ITTEHAD FOOD INDUSTRIES","debit":29000,"credit":0},{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-5997 ITTEHAD FOOD INDUSTRIES from. ISC CROP SCIENCES","debit":0,"credit":29000}]', 29000, 'JV.JOU-5997 ISC CROP SCIENCES from. ITTEHAD FOOD INDUSTRIES | JV.JOU-5997 ITTEHAD FOOD INDUSTRIES from. ISC CROP SCIENCES', 'System Administrator', '2026-07-23 15:43:54.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821393954', 'JOU-4944', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-4944 ITTEHAD FOOD INDUSTRIES from. ABDUL SATTAR & SONS","debit":500000,"credit":0},{"accountId":"acc-452379","accountName":"ABDUL SATTAR & SONS","description":"JV.JOU-4944 ABDUL SATTAR & SONS from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":500000}]', 500000, 'JV.JOU-4944 ITTEHAD FOOD INDUSTRIES from. ABDUL SATTAR & SONS | JV.JOU-4944 ABDUL SATTAR & SONS from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-23 15:43:13.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821346715', 'JOU-5303', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-5303 ITTEHAD FOOD INDUSTRIES from. WALI MUHAMMAD & COMPANY","debit":500000,"credit":0},{"accountId":"acc-451563","accountName":"WALI MUHAMMAD & COMPANY","description":"JV.JOU-5303 WALI MUHAMMAD & COMPANY from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":500000}]', 500000, 'JV.JOU-5303 ITTEHAD FOOD INDUSTRIES from. WALI MUHAMMAD & COMPANY | JV.JOU-5303 WALI MUHAMMAD & COMPANY from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-23 15:42:26.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821297883', 'JOU-7221', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-7221 CASH ENTRY ITTEHAD ZARI from. ABDUL MAJEED GRAIN MARKET","debit":900000,"credit":0},{"accountId":"acc-452038","accountName":"ABDUL MAJEED GRAIN MARKET","description":"JV.JOU-7221 ABDUL MAJEED GRAIN MARKET from. CASH ENTRY ITTEHAD ZARI","debit":0,"credit":900000}]', 900000, 'JV.JOU-7221 CASH ENTRY ITTEHAD ZARI from. ABDUL MAJEED GRAIN MARKET | JV.JOU-7221 ABDUL MAJEED GRAIN MARKET from. CASH ENTRY ITTEHAD ZARI', 'System Administrator', '2026-07-23 15:41:37.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821245724', 'JOU-5093', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-5093 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA","debit":500000,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-5093 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":500000}]', 500000, 'JV.JOU-5093 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA | JV.JOU-5093 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-23 15:40:45.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821193724', 'JOU-4029', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-452492","accountName":"KISSAN C/S","description":"JV.JOU-4029 KISSAN C/S from. CASH ENTRY ITTEHAD ZARI","debit":212800,"credit":0},{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-4029 CASH ENTRY ITTEHAD ZARI from. KISSAN C/S","debit":0,"credit":212800}]', 212800, 'JV.JOU-4029 KISSAN C/S from. CASH ENTRY ITTEHAD ZARI | JV.JOU-4029 CASH ENTRY ITTEHAD ZARI from. KISSAN C/S', 'System Administrator', '2026-07-23 15:39:53.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821146324', 'JOU-3751', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451494","accountName":"CASH ENTRY ITTEHAD ZARI","description":"JV.JOU-3751 CASH ENTRY ITTEHAD ZARI from. NAYA SAWERA ADDA RANG SHAH","debit":60000,"credit":0},{"accountId":"acc-452115","accountName":"NAYA SAWERA ADDA RANG SHAH","description":"JV.JOU-3751 NAYA SAWERA ADDA RANG SHAH from. CASH ENTRY ITTEHAD ZARI","debit":0,"credit":60000}]', 60000, 'JV.JOU-3751 CASH ENTRY ITTEHAD ZARI from. NAYA SAWERA ADDA RANG SHAH | JV.JOU-3751 NAYA SAWERA ADDA RANG SHAH from. CASH ENTRY ITTEHAD ZARI', 'System Administrator', '2026-07-23 15:39:06.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784821050934', 'JOU-7686', 'JOURNAL', '2026-07-23', NULL, '[{"accountId":"acc-451914","accountName":"ITTEHAD FOOD INDUSTRIES","description":"JV.JOU-7686 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA","debit":54300,"credit":0},{"accountId":"acc-410835","accountName":"HBL NEW A/C LARI ADDA","description":"JV.JOU-7686 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES","debit":0,"credit":54300}]', 54300, 'JV.JOU-7686 ITTEHAD FOOD INDUSTRIES from. HBL NEW A/C LARI ADDA | JV.JOU-7686 HBL NEW A/C LARI ADDA from. ITTEHAD FOOD INDUSTRIES', 'System Administrator', '2026-07-23 15:37:30.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800431454', 'CAS-2804', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430813","accountName":"FUEL EXPENCES","description":"Cash paid to.FUEL EXPENCES","debit":4200,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.FUEL EXPENCES","debit":0,"credit":4200}]', 4200, 'Cash paid to.FUEL EXPENCES', 'System Administrator', '2026-07-23 09:53:51.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800412591', 'CAS-8494', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430814","accountName":"MACHINERY REPAIR EXPENCES","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":1700,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":0,"credit":1700}]', 1700, 'Cash paid to.MACHINERY REPAIR EXPENCES', 'System Administrator', '2026-07-23 09:53:32.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800381689', 'CAS-4611', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430845","accountName":"SOCIAL SECURITY","description":"Cash paid to.SOCIAL SECURITY","debit":25200,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.SOCIAL SECURITY","debit":0,"credit":25200}]', 25200, 'Cash paid to.SOCIAL SECURITY', 'System Administrator', '2026-07-23 09:53:01.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800361089', 'CAS-5638', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-452328","accountName":"SAJID M GUNMAN","description":"Cash paid to.SAJID M GUNMAN","debit":10000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.SAJID M GUNMAN","debit":0,"credit":10000}]', 10000, 'Cash paid to.SAJID M GUNMAN', 'System Administrator', '2026-07-23 09:52:41.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800198633', 'CAS-3336', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430814","accountName":"MACHINERY REPAIR EXPENCES","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":9500,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":0,"credit":9500}]', 9500, 'Cash paid to.MACHINERY REPAIR EXPENCES', 'System Administrator', '2026-07-23 09:49:58.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800175217', 'CAS-2006', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430814","accountName":"MACHINERY REPAIR EXPENCES","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":5400,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":0,"credit":5400}]', 5400, 'Cash paid to.MACHINERY REPAIR EXPENCES', 'System Administrator', '2026-07-23 09:49:35.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800052283', 'CAS-1099', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430814","accountName":"MACHINERY REPAIR EXPENCES","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":12000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MACHINERY REPAIR EXPENCES","debit":0,"credit":12000}]', 12000, 'Cash paid to.MACHINERY REPAIR EXPENCES', 'System Administrator', '2026-07-23 09:47:32.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800024518', 'CAS-5604', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451584","accountName":"PAK AFGHOI MIS. EXP","description":"Cash paid to.PAK AFGHOI MIS. EXP","debit":44700,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.PAK AFGHOI MIS. EXP","debit":0,"credit":44700}]', 44700, 'Cash paid to.PAK AFGHOI MIS. EXP', 'System Administrator', '2026-07-23 09:47:04.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784800002938', 'CAS-8566', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451314","accountName":"MUNEER AHMAD ITTEHAD SEED","description":"Cash paid to.MUNEER AHMAD ITTEHAD SEED","debit":15000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.MUNEER AHMAD ITTEHAD SEED","debit":0,"credit":15000}]', 15000, 'Cash paid to.MUNEER AHMAD ITTEHAD SEED', 'System Administrator', '2026-07-23 09:46:42.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784799965595', 'CAS-6552', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-452867","accountName":"ABID COOK 69/EB","description":"Cash paid to.ABID COOK 69/EB","debit":10000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ABID COOK 69/EB","debit":0,"credit":10000}]', 10000, 'Cash paid to.ABID COOK 69/EB', 'System Administrator', '2026-07-23 09:46:05.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784799942010', 'CAS-1551', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430815","accountName":"TRAVELLING EXP.","description":"Cash paid to.TRAVELLING EXP.","debit":5000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.TRAVELLING EXP.","debit":0,"credit":5000}]', 5000, 'Cash paid to.TRAVELLING EXP.', 'System Administrator', '2026-07-23 09:45:42.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784799919116', 'CAS-4156', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-452035","accountName":"CHARIETY A/C","description":"Cash paid to.CHARIETY A/C","debit":2000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.CHARIETY A/C","debit":0,"credit":2000}]', 2000, 'Cash paid to.CHARIETY A/C', 'System Administrator', '2026-07-23 09:45:19.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784799901683', 'CAS-7821', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-430800","accountName":"ENTERTAINMENT A/C","description":"Cash paid to.ENTERTAINMENT A/C","debit":21000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.ENTERTAINMENT A/C","debit":0,"credit":21000}]', 21000, 'Cash paid to.ENTERTAINMENT A/C', 'System Administrator', '2026-07-23 09:45:01.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

INSERT INTO `vouchers` (`id`, `voucher_no`, `voucher_type`, `date`, `sales_staff`, `lines`, `total_amount`, `narration`, `created_by`, `created_at`) VALUES
('vch_1784799870537', 'CAS-7446', 'CASH_PAYMENT', '2026-07-23', NULL, '[{"accountId":"acc-451886","accountName":"LIMIT EXP","description":"Cash paid to.LIMIT EXP","debit":7000,"credit":0},{"accountId":"acc-410800","accountName":"CASH-IN-HAND","description":"Cash paid to.LIMIT EXP","debit":0,"credit":7000}]', 7000, 'Cash paid to.LIMIT EXP', 'System Administrator', '2026-07-23 09:44:30.000')
ON DUPLICATE KEY UPDATE `voucher_no` = VALUES(`voucher_no`), `lines` = VALUES(`lines`), `total_amount` = VALUES(`total_amount`);

