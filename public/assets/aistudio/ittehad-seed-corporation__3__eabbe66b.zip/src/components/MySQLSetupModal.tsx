import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { DatabaseStatus, MySQLConfig } from '../types';
import {
  X,
  Database,
  CheckCircle2,
  Copy,
  Terminal,
  Download,
  RefreshCw,
  AlertCircle,
  HelpCircle,
  Server,
  Zap,
  ArrowRight,
  WifiOff,
  FileText,
  Check,
  ShieldAlert,
  Globe
} from 'lucide-react';

interface MySQLSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigured: () => void;
}

export const MySQLSetupModal: React.FC<MySQLSetupModalProps> = ({ isOpen, onClose, onConfigured }) => {
  const [status, setStatus] = useState<DatabaseStatus>({ type: 'local', connected: false });
  const [host, setHost] = useState('mysql.gb.stackcp.com');
  const [port, setPort] = useState(45563);
  const [user, setUser] = useState('nasir-19a2');
  const [password, setPassword] = useState('Nasir@22wb');
  const [database, setDatabase] = useState('ittehadseed-35303437efb4');
  const [ssl, setSsl] = useState(false);
  const [activeTab, setActiveTab] = useState<'config' | 'stackcp' | 'bridge' | 'sql'>('config');
  const [sqlMode, setSqlMode] = useState<'schema' | 'full'>('schema');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [message, setMessage] = useState<{
    type: 'success' | 'error';
    text: string;
    isLocalhost?: boolean;
    isStackcp?: boolean;
    suggestedHost?: string;
  } | null>(null);
  const [sqlSchema, setSqlSchema] = useState('');
  const [fullSqlDump, setFullSqlDump] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadStatus();
      loadSchema();
    }
  }, [isOpen]);

  const loadStatus = async () => {
    const s = await db.getDatabaseStatus();
    setStatus(s);
    if (s.host) setHost(s.host);
    if (s.port) setPort(s.port);
    if (s.database) setDatabase(s.database);
    if (s.user) setUser(s.user);
    if (s.connected) {
      setMessage({ type: 'success', text: s.message || 'Connected to MySQL Server' });
    } else if (s.isLocalhostRefused) {
      setMessage({
        type: 'error',
        text: s.message || 'connect ECONNREFUSED 127.0.0.1:3306',
        isLocalhost: true
      });
    } else if (s.message && !s.message.includes('Running on fast local')) {
      setMessage({
        type: 'error',
        text: s.message,
        isStackcp: s.isStackcp,
        suggestedHost: s.suggestedHost
      });
    }
  };

  const loadSchema = async () => {
    const schema = await db.getMySQLSchema();
    setSqlSchema(schema);
    const dump = await db.getMySQLExportDataSql();
    setFullSqlDump(dump);
  };

  if (!isOpen) return null;

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    let cleanHost = host.trim();
    const cleanPort = Number(port);
    const isLocal = cleanHost === '127.0.0.1' || cleanHost === 'localhost' || cleanHost === '::1';

    const config: MySQLConfig = {
      host: cleanHost,
      port: cleanPort,
      user: user.trim(),
      password,
      database: database.trim(),
      ssl
    };

    const res = await db.setMySQLConfig(config);
    setLoading(false);

    if (res.success) {
      setMessage({ type: 'success', text: res.message || 'Connected to MySQL successfully!' });
      await loadStatus();
      onConfigured();
    } else {
      const isRefused = Boolean(res.isLocalhostRefused || (isLocal && res.error?.includes('ECONNREFUSED')));
      const isStackcp = Boolean(
        res.isStackcp ||
        cleanHost.toLowerCase().includes('stackcp') ||
        res.error?.toLowerCase().includes('stackcp') ||
        res.error?.toLowerCase().includes('sdb-67') ||
        cleanHost.toLowerCase().includes('sdb-')
      );

      setMessage({
        type: 'error',
        text: res.error || `connect ECONNREFUSED ${cleanHost}:${cleanPort}`,
        isLocalhost: isRefused,
        isStackcp,
        suggestedHost: res.suggestedHost || cleanHost
      });
    }
  };

  const handleDisconnect = async () => {
    await db.disconnectMySQL();
    await loadStatus();
    setMessage({ type: 'success', text: 'Disconnected from MySQL. Switched to high-performance local storage engine.' });
    onConfigured();
  };

  const handleCopyText = (text: string, id?: string) => {
    navigator.clipboard.writeText(text);
    if (id) {
      setCopiedCmd(id);
      setTimeout(() => setCopiedCmd(null), 2000);
    } else {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadSql = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-3xl rounded-2xl bg-white shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between bg-emerald-900 px-6 py-4 text-white">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-800 flex items-center justify-center border border-emerald-700 shadow-inner">
              <Database className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-lg font-bold">MySQL Database Backend Setup</h2>
              <p className="text-xs text-emerald-200">
                Ittehad Seed Corporation &bull; Database: <span className="font-mono text-white font-semibold">ittehadseed-35303437efb4</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status banner */}
        <div
          className={`px-6 py-2.5 flex items-center justify-between text-xs font-semibold ${
            status.connected
              ? 'bg-emerald-100 text-emerald-900 border-b border-emerald-200'
              : 'bg-amber-50 text-amber-900 border-b border-amber-200'
          }`}
        >
          <div className="flex items-center space-x-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                status.connected ? 'bg-emerald-600 animate-pulse' : 'bg-amber-600'
              }`}
            ></span>
            <span>
              {status.connected
                ? `MySQL Status: Connected to database "${status.database}" on ${status.host}:${status.port || 3306}`
                : 'Storage Status: Built-in High-Performance Storage Engine Active (All data safely preserved)'}
            </span>
          </div>
          <button
            onClick={loadStatus}
            className="text-xs underline hover:no-underline flex items-center space-x-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Refresh</span>
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-gray-200 bg-gray-50 px-6">
          <button
            onClick={() => setActiveTab('config')}
            className={`py-3 px-4 font-semibold text-sm border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'config'
                ? 'border-emerald-700 text-emerald-800 bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Connection Parameters</span>
          </button>

          <button
            onClick={() => setActiveTab('stackcp')}
            className={`py-3 px-4 font-semibold text-sm border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'stackcp'
                ? 'border-emerald-700 text-emerald-800 bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Globe className="w-4 h-4 text-emerald-600" />
            <span>StackCP / cPanel Guide</span>
            {(message?.isStackcp || host.includes('stackcp')) && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('bridge')}
            className={`py-3 px-4 font-semibold text-sm border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'bridge'
                ? 'border-emerald-700 text-emerald-800 bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-amber-600" />
            <span>PC Localhost Bridge</span>
            {message?.isLocalhost && (
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('sql')}
            className={`py-3 px-4 font-semibold text-sm border-b-2 transition-colors flex items-center space-x-2 ${
              activeTab === 'sql'
                ? 'border-emerald-700 text-emerald-800 bg-white'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>phpMyAdmin SQL Scripts</span>
          </button>
        </div>

        {/* Tab content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: CONNECTION PARAMETERS */}
          {activeTab === 'config' && (
            <div className="space-y-4">
              {/* STACKCP ERROR SPECIFIC BANNER */}
              {(message?.isStackcp || host.toLowerCase().includes('stackcp') || message?.text.includes('ENOTFOUND')) && (
                <div className="rounded-xl border border-amber-300 bg-amber-50/90 p-4 space-y-3 shadow-xs">
                  <div className="flex items-start space-x-3">
                    <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-amber-950">
                        Fixing StackCP: <code className="bg-amber-100 text-amber-900 px-1 py-0.5 rounded font-mono text-xs">getaddrinfo ENOTFOUND sdb-67.hosting.stackcp.net</code>
                      </h4>
                      <div className="text-xs text-amber-900 space-y-1 leading-relaxed">
                        <p>
                          <strong>1. Domain Suffix:</strong> The domain is <code className="font-bold font-mono bg-white px-1 rounded">.com</code>, NOT <code className="line-through font-mono">.net</code>. (<code className="font-mono">sdb-67.hosting.stackcp.com</code>).
                        </p>
                        <p>
                          <strong>2. Remote Gateway Hostname:</strong> In StackCP / 20i hosting, remote connections from outside the server must use the gateway host <code className="font-bold font-mono bg-white px-1.5 py-0.5 rounded text-emerald-800">mysql.gb.stackcp.com</code>.
                        </p>
                        <p>
                          <strong>3. Whitelist IP in StackCP:</strong> StackCP blocks remote MySQL by default. Go to <strong>StackCP &rarr; Web Tools &rarr; Remote MySQL Access</strong>, select your user, enter <code className="font-mono font-bold bg-white px-1 rounded">%</code> (or app IP <code className="font-mono bg-white px-1 rounded">34.34.254.199</code>), and click <strong>Add Host</strong>.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-amber-200">
                    <button
                      type="button"
                      onClick={() => setActiveTab('stackcp')}
                      className="px-3 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-900 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                    >
                      <span>View StackCP Step-by-Step Guide</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Standard Message Alert */}
              {message && !message.isStackcp && (
                <div
                  className={`p-4 rounded-xl flex items-center space-x-3 text-sm ${
                    message.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-red-50 text-red-800 border border-red-200'
                  }`}
                >
                  {message.type === 'success' ? (
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
                  )}
                  <span className="font-medium text-xs leading-relaxed">{message.text}</span>
                </div>
              )}

              <form onSubmit={handleConnect} className="space-y-4">
                <div className="rounded-xl bg-emerald-50/70 p-4 text-xs text-emerald-900 border border-emerald-200 space-y-1">
                  <p className="font-bold text-emerald-950 flex items-center space-x-1.5">
                    <Database className="w-4 h-4 text-emerald-700" />
                    <span>Live StackCP / Remote MySQL Connection</span>
                  </p>
                  <p className="text-gray-700">
                    Connect to your StackCP or remote MySQL database. All 8 tables with proper Date &amp; Financial types will be verified or created automatically.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold uppercase text-gray-700">
                        MySQL Host / IP Address
                      </label>
                    </div>
                    <input
                      type="text"
                      required
                      placeholder="sdb-67.hosting.stackcp.net"
                      value={host}
                      onChange={e => setHost(e.target.value)}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono"
                    />
                    <p className="text-[11px] text-gray-500 mt-1">
                      Your configured MySQL server address (e.g. <span className="font-mono text-emerald-700 font-semibold">sdb-67.hosting.stackcp.net</span>).
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-gray-700 mb-1">Port</label>
                    <input
                      type="number"
                      required
                      value={port}
                      onChange={e => setPort(Number(e.target.value))}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono"
                    />
                    <p className="text-[11px] text-gray-500 mt-1">
                      Your StackCP remote port (e.g. <span className="font-mono font-semibold">33210</span>)
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-gray-700 mb-1">
                      Database Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="ittehadseed-35303437efb4"
                      value={database}
                      onChange={e => setDatabase(e.target.value)}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono text-xs font-semibold text-emerald-900 bg-emerald-50/30"
                    />
                    <p className="text-[11px] text-gray-500 mt-1">
                      Auto-created if permissions allow, or run schema from SQL tab.
                    </p>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-gray-700 mb-1">Username</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., ittehadseed-35303437efb4 or root"
                      value={user}
                      onChange={e => setUser(e.target.value)}
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono"
                    />
                    <p className="text-[11px] text-gray-500 mt-1">
                      Your database user created in StackCP / cPanel.
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-gray-700 mb-1">Password</label>
                  <input
                    type="password"
                    placeholder="Enter database user password from StackCP"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono"
                  />
                </div>

                <div className="flex items-center space-x-2 pt-1">
                  <input
                    type="checkbox"
                    id="sslCheck"
                    checked={ssl}
                    onChange={e => setSsl(e.target.checked)}
                    className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <label htmlFor="sslCheck" className="text-xs text-gray-700 font-medium cursor-pointer">
                    Enable SSL / TLS Encryption
                  </label>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  {status.connected ? (
                    <button
                      type="button"
                      onClick={handleDisconnect}
                      className="px-4 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 rounded-lg border border-red-200 transition-colors cursor-pointer"
                    >
                      Disconnect MySQL (Use Built-in Storage)
                    </button>
                  ) : (
                    <span className="text-xs text-gray-500 font-medium">
                      Built-in storage engine currently active
                    </span>
                  )}
                  <div className="flex space-x-3">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
                    >
                      Close
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-6 py-2.5 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors flex items-center space-x-2 disabled:opacity-50 cursor-pointer"
                    >
                      <Database className="w-4 h-4" />
                      <span>{loading ? 'Testing & Connecting...' : 'Test & Connect MySQL'}</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: STACKCP / CPANEL STEP-BY-STEP GUIDE */}
          {activeTab === 'stackcp' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl space-y-2">
                <h3 className="text-sm font-bold text-emerald-950 flex items-center space-x-2">
                  <Globe className="w-4 h-4 text-emerald-700" />
                  <span>Configuring StackCP / 20i Remote MySQL Access</span>
                </h3>
                <p className="text-xs text-emerald-900 leading-relaxed">
                  StackCP hosting requires remote IP whitelisting and uses a dedicated remote gateway hostname (<code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded text-emerald-800">mysql.gb.stackcp.com</code>). Follow these 3 simple steps to connect:
                </p>
              </div>

              <div className="space-y-4">
                {/* Step 1 */}
                <div className="border border-gray-200 rounded-xl p-4 bg-white space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-800 text-white text-xs font-bold flex items-center justify-center">1</span>
                    <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wide">
                      Use the Correct Hostname (Avoid .net)
                    </h4>
                  </div>
                  <p className="text-xs text-gray-700 pl-8 leading-relaxed">
                    StackCP domains end in <strong className="text-emerald-800">.com</strong>, not .net. For remote access, StackCP documentation specifies the gateway:
                  </p>
                  <div className="pl-8 flex items-center space-x-2">
                    <div className="bg-gray-900 text-emerald-400 font-mono text-xs px-3 py-2 rounded-lg flex-1">
                      mysql.gb.stackcp.com
                    </div>
                    <button
                      onClick={() => {
                        setHost('mysql.gb.stackcp.com');
                        setActiveTab('config');
                      }}
                      className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      Apply Host
                    </button>
                  </div>
                  <p className="text-[11px] text-gray-500 pl-8">
                    (Alternatively, you can also test <code className="font-mono">sdb-67.hosting.stackcp.com</code>).
                  </p>
                </div>

                {/* Step 2 */}
                <div className="border border-amber-200 rounded-xl p-4 bg-amber-50/50 space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-amber-600 text-white text-xs font-bold flex items-center justify-center">2</span>
                    <h4 className="text-xs font-bold text-amber-950 uppercase tracking-wide">
                      Whitelist Remote Access in StackCP (Required!)
                    </h4>
                  </div>
                  <div className="text-xs text-amber-950 pl-8 space-y-1.5 leading-relaxed">
                    <p>StackCP firewall blocks all external MySQL connections until you add an Access Host:</p>
                    <ol className="list-decimal pl-5 space-y-1">
                      <li>Log in to your <strong>StackCP control panel</strong>.</li>
                      <li>Go to <strong>Manage Hosting</strong> &rarr; click <strong>Options</strong> &rarr; <strong>Manage</strong>.</li>
                      <li>Scroll to the <strong>Web Tools</strong> section and click <strong>Remote MySQL Access</strong>.</li>
                      <li>Under <strong>Add Access Host</strong>, select your database user from the dropdown.</li>
                      <li>
                        In the <strong>Access Host</strong> box, enter <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded text-emerald-800">%</code> (wildcard allowing any connection) or the app outbound IP:
                      </li>
                    </ol>
                    <div className="flex items-center space-x-2 pt-1">
                      <div className="bg-gray-900 text-emerald-400 font-mono text-xs px-3 py-1.5 rounded-lg flex-1">
                        {status.outboundIp || '34.96.48.119'}
                      </div>
                      <button
                        onClick={() => handleCopyText(status.outboundIp || '34.96.48.119', 'ip')}
                        className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-white rounded-lg text-xs flex items-center space-x-1 cursor-pointer"
                      >
                        {copiedCmd === 'ip' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedCmd === 'ip' ? 'Copied' : 'Copy IP'}</span>
                      </button>
                    </div>
                    <li>Click <strong>Add Host</strong>.</li>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="border border-gray-200 rounded-xl p-4 bg-white space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-800 text-white text-xs font-bold flex items-center justify-center">3</span>
                    <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wide">
                      Verify Your Custom Remote Port
                    </h4>
                  </div>
                  <p className="text-xs text-gray-700 pl-8 leading-relaxed">
                    StackCP does not use standard port 3306 for remote connections; it displays a specific port number on the <strong>Remote MySQL Access</strong> screen (for example, <code className="font-mono font-bold text-emerald-800 bg-gray-100 px-1.5 py-0.5 rounded">33210</code>). Make sure the port in your connection parameters matches!
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LOCAL MACHINE BRIDGE GUIDE */}
          {activeTab === 'bridge' && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl space-y-2">
                <h3 className="text-sm font-bold text-amber-950 flex items-center space-x-2">
                  <HelpCircle className="w-4 h-4 text-amber-700" />
                  <span>Connecting Localhost (127.0.0.1) on Your Computer</span>
                </h3>
                <p className="text-xs text-amber-900 leading-relaxed">
                  If you run MySQL or XAMPP on your personal computer, <code className="font-mono bg-amber-100 px-1 py-0.5 rounded text-amber-900 font-semibold">127.0.0.1</code> is private to your PC. To allow this cloud application to reach your local MySQL, run this one command on your computer:
                </p>
              </div>

              <div className="border border-emerald-200 rounded-xl p-4 bg-emerald-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-700 text-white">
                    10 Seconds &bull; Zero Installation
                  </span>
                  <span className="text-xs font-medium text-emerald-800">Windows CMD, PowerShell &amp; Mac</span>
                </div>
                <div className="flex items-center space-x-2 bg-gray-900 p-3 rounded-lg text-emerald-400 font-mono text-xs">
                  <span className="flex-1 select-all">ssh -p 443 -R0:localhost:3306 a.pinggy.io</span>
                  <button
                    onClick={() => handleCopyText('ssh -p 443 -R0:localhost:3306 a.pinggy.io', 'pinggy')}
                    className="px-2.5 py-1 bg-gray-800 hover:bg-gray-700 text-white rounded text-xs flex items-center space-x-1 cursor-pointer"
                  >
                    {copiedCmd === 'pinggy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCmd === 'pinggy' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-xs text-gray-600">
                  It will display an address like <code className="font-mono bg-gray-100 px-1.5 py-0.5 rounded font-bold text-emerald-800">tcp://a.pinggy.io:45821</code>.
                  Enter <code className="font-mono bg-gray-100 px-1 rounded">a.pinggy.io</code> in <strong>Host</strong> and <code className="font-mono bg-gray-100 px-1 rounded">45821</code> in <strong>Port</strong> on the Connection tab!
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: PHPMYADMIN SQL SCRIPTS */}
          {activeTab === 'sql' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2 bg-gray-50 p-3 rounded-xl border border-gray-200">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSqlMode('schema')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      sqlMode === 'schema'
                        ? 'bg-emerald-700 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                    }`}
                  >
                    1. Table Creation DDL (Schema)
                  </button>
                  <button
                    onClick={() => setSqlMode('full')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center space-x-1.5 ${
                      sqlMode === 'full'
                        ? 'bg-emerald-700 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>2. Complete Database &amp; Data Export (phpMyAdmin)</span>
                  </button>
                </div>

                <div className="flex space-x-2">
                  <button
                    onClick={() => handleCopyText(sqlMode === 'schema' ? sqlSchema : fullSqlDump)}
                    className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-medium cursor-pointer"
                  >
                    {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL'}</span>
                  </button>
                  <button
                    onClick={() =>
                      handleDownloadSql(
                        sqlMode === 'schema' ? sqlSchema : fullSqlDump,
                        sqlMode === 'schema'
                          ? 'ittehad_seed_mysql_schema.sql'
                          : 'ittehadseed_database_backup.sql'
                      )
                    }
                    className="flex items-center space-x-1 px-3 py-1.5 bg-gray-800 hover:bg-gray-900 text-white rounded-lg text-xs font-medium cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .sql</span>
                  </button>
                </div>
              </div>

              <div className="text-xs text-gray-600 space-y-1">
                <p>
                  <strong>How to run in StackCP / phpMyAdmin:</strong>
                </p>
                <ol className="list-decimal pl-5 space-y-0.5 text-gray-700">
                  <li>In StackCP, open <strong>phpMyAdmin</strong> from your MySQL databases section.</li>
                  <li>Click on the <strong>SQL</strong> tab at the top.</li>
                  <li>Paste the SQL script below and click <strong>Go</strong>.</li>
                  <li>It will create all 8 tables with proper <code className="font-mono">DATE</code> and financial types, relational indexes, and standard initial data.</li>
                </ol>
              </div>

              <pre className="p-4 bg-gray-950 text-emerald-400 text-xs rounded-xl font-mono overflow-x-auto max-h-96 border border-gray-800 leading-relaxed select-all">
                {sqlMode === 'schema' ? sqlSchema : fullSqlDump}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
