import React, { useEffect, useState } from 'react';
import { db } from '../services/db';
import { formatDate } from '../utils/dateUtils';
import {
  BookOpen,
  Package,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
  Wallet,
  Clock,
  Building2,
  Phone
} from 'lucide-react';

interface DashboardProps {
  onNavigate?: (tab: string, ref?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<any>({
    totalAccounts: 0,
    totalProducts: 0,
    totalSales: 0,
    totalPurchases: 0,
    cashReceipts: 0,
    cashPayments: 0,
    todaysSales: 0,
    todaysPurchases: 0,
    cashBalance: 0,
    recentTransactions: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const data = await db.getDashboardStats();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-12 text-center text-gray-500 flex flex-col items-center justify-center space-y-3">
        <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
        <p className="font-semibold text-sm">Loading Ittehad Seed Corporation Dashboard...</p>
      </div>
    );
  }

  const kpiCards = [
    { title: 'Current Cash Balance', value: `PKR ${stats.cashBalance.toLocaleString()}`, icon: Wallet, color: 'bg-emerald-700' },
    { title: "Today's Sales", value: `PKR ${stats.todaysSales.toLocaleString()}`, icon: TrendingUp, color: 'bg-blue-600' },
    { title: "Today's Purchases", value: `PKR ${stats.todaysPurchases.toLocaleString()}`, icon: TrendingDown, color: 'bg-amber-600' },
    { title: 'Total Sales', value: `PKR ${stats.totalSales.toLocaleString()}`, icon: ArrowUpRight, color: 'bg-teal-700' },
    { title: 'Total Purchases', value: `PKR ${stats.totalPurchases.toLocaleString()}`, icon: ArrowDownLeft, color: 'bg-indigo-600' },
    { title: 'Cash Receipts', value: `PKR ${stats.cashReceipts.toLocaleString()}`, icon: DollarSign, color: 'bg-emerald-600' },
    { title: 'Cash Payments', value: `PKR ${stats.cashPayments.toLocaleString()}`, icon: DollarSign, color: 'bg-rose-600' },
    { title: 'Chart of Accounts', value: stats.totalAccounts, icon: BookOpen, color: 'bg-purple-600' },
    { title: 'Products & Varieties', value: stats.totalProducts, icon: Package, color: 'bg-cyan-600' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-800 rounded-2xl p-6 text-white shadow-md flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center p-1 shadow-md border-2 border-emerald-400">
            <img src="/logoittehad.png" alt="Ittehad Seed Corporation" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-wide uppercase">ITTEHAD SEED CORPORATION</h2>
            <div className="flex items-center space-x-3 text-xs text-emerald-200 mt-1">
              <span className="flex items-center space-x-1">
                <Building2 className="w-3.5 h-3.5" />
                <span>Qaboola Road Arifwala</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <Phone className="w-3.5 h-3.5" />
                <span>03216533233</span>
              </span>
            </div>
          </div>
        </div>
        <div className="text-right text-xs bg-emerald-900/80 px-4 py-2 rounded-xl border border-emerald-700">
          <p className="text-emerald-300">Financial Year</p>
          <p className="text-sm font-bold text-white">2026 - 2027</p>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpiCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div key={idx} className="bg-white rounded-xl p-5 border border-gray-200 shadow-xs flex items-center justify-between hover:shadow-md transition-shadow">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">{card.title}</p>
                <p className="text-xl font-black text-gray-800 mt-1">{card.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl ${card.color} text-white flex items-center justify-center shadow-md shrink-0`}>
                <Icon className="w-6 h-6" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Transactions Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-emerald-700" />
            <h3 className="text-lg font-bold text-gray-800">Recent Transactions</h3>
          </div>
          <span className="text-xs text-gray-500 font-medium">Click on any reference number to view details</span>
        </div>

        {stats.recentTransactions.length === 0 ? (
          <div className="text-center py-12 text-gray-400 bg-gray-50 rounded-xl border border-dashed border-gray-200">
            <p className="font-medium">No transactions recorded yet.</p>
            <p className="text-xs text-gray-400 mt-1">Add sales invoices, purchase invoices, or cash vouchers to see entries here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-xs font-semibold uppercase text-gray-500 bg-gray-50">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Reference No</th>
                  <th className="py-3 px-4 text-right">Amount (PKR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {stats.recentTransactions.map((tx: any, idx: number) => {
                  let targetTab = 'sales_inv';
                  if (tx.type === 'Sale Invoice') targetTab = 'sales_inv';
                  else if (tx.type === 'Purchase Invoice') targetTab = 'purchase_inv';
                  else if (tx.type === 'CASH PAYMENT') targetTab = 'cpv';
                  else if (tx.type === 'CASH RECEIPT') targetTab = 'crv';
                  else if (tx.type === 'JOURNAL') targetTab = 'jv';

                  return (
                    <tr
                      key={idx}
                      className="hover:bg-emerald-50/50 cursor-pointer transition-colors"
                      onClick={() => onNavigate && onNavigate(targetTab, tx.ref)}
                      title="Click to open this transaction"
                    >
                      <td className="py-3 px-4 text-gray-600 font-mono text-xs">{formatDate(tx.date)}</td>
                      <td className="py-3 px-4 font-semibold text-gray-800">
                        <span className="inline-flex px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-700">
                          {tx.type}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-emerald-700 font-mono font-bold underline hover:text-emerald-900">
                        {tx.ref}
                      </td>
                      <td className="py-3 px-4 text-right font-black text-gray-900">
                        {tx.amount.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
