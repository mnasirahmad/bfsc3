import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Account, Product } from '../types';
import { Printer, Download, Search, Eye, X } from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  printReportDirect,
  downloadPdfFromReportHtml,
  buildStandardReportHeaderHtml,
  buildStandardReportFooterHtml
} from '../utils/reportPrinter';
import { formatDate } from '../utils/dateUtils';

export const LedgersComponent: React.FC = () => {
  const [ledgerType, setLedgerType] = useState<'account' | 'product'>('account');
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [companyProfile, setCompanyProfile] = useState<any>(null);
  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [accountSearch, setAccountSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('2026-01-01');
  const [dateTo, setDateTo] = useState(new Date().toISOString().split('T')[0]);
  const [accountLedgerData, setAccountLedgerData] = useState<any[]>([]);
  const [productLedgerData, setProductLedgerData] = useState<any[]>([]);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [hasGeneratedAccountLedger, setHasGeneratedAccountLedger] = useState<boolean>(false);

  useEffect(() => {
    loadMasters();
  }, []);

  const loadMasters = async () => {
    const accs = await db.getAccounts();
    const prods = await db.getProducts();
    const profile = await db.getCompanyProfile();
    setAccounts(accs);
    setProducts(prods);
    setCompanyProfile(profile);
    if (accs.length > 0) {
      const cashInHand = accs.find(a => a.code === 'ACC-10000' || a.name.toUpperCase().includes('CASH IN HAND'));
      setSelectedAccountId(cashInHand ? cashInHand.id : accs[0].id);
    }
    if (prods.length > 0) setSelectedProductId(prods[0].id);
  };

  const selectedAccount = accounts.find(a => a.id === selectedAccountId);
  const selectedProduct = products.find(p => p.id === selectedProductId);

  // Reset generated state when account or dates change for account ledger
  useEffect(() => {
    setHasGeneratedAccountLedger(false);
  }, [selectedAccountId, dateFrom, dateTo]);

  // Product ledger can still auto-generate or stay as is, but account ledger is strictly manual per user request
  useEffect(() => {
    if (products.length > 0 && selectedProductId && ledgerType === 'product') {
      handleGenerate(undefined, selectedProductId);
    }
  }, [selectedProductId, ledgerType, dateFrom, dateTo, products.length]);

  const handleGenerate = async (customAccId?: string, customProdId?: string) => {
    const targetAccId = customAccId || selectedAccountId;
    const targetProdId = customProdId || selectedProductId;

    if (ledgerType === 'account') {
      setHasGeneratedAccountLedger(true);
      const acc = accounts.find(a => a.id === targetAccId);
      if (!acc) return;
      const vouchers = await db.getVouchers();
      const invoices = await db.getInvoices();

      let runningBalance = acc.openingBalanceType === 'Dr' ? Number(acc.openingBalance || 0) : -Number(acc.openingBalance || 0);

      // Sum all transactions strictly before dateFrom
      vouchers.forEach(v => {
        const vDate = v.date ? v.date.split('T')[0] : '';
        if (vDate && vDate < dateFrom) {
          v.lines?.forEach(l => {
            if (l.accountId === targetAccId) {
              runningBalance += Number(l.debit || 0) - Number(l.credit || 0);
            }
          });
        }
      });

      invoices.forEach(inv => {
        const invDate = inv.date ? inv.date.split('T')[0] : '';
        if (invDate && invDate < dateFrom) {
          if (
            inv.accountName === acc.name ||
            inv.accountName === acc.id ||
            inv.accountName.toLowerCase() === acc.name.toLowerCase()
          ) {
            let debit = 0;
            let credit = 0;
            if (inv.invoiceType === 'SALES_CASH' || inv.invoiceType === 'SALES_CREDIT' || inv.invoiceType === 'SALES_MAUND' || inv.invoiceType === 'PURCHASE_RETURN') {
              debit = Number(inv.netTotal || 0);
            } else if (inv.invoiceType === 'SALES_RETURN' || inv.invoiceType === 'PURCHASE_CASH' || inv.invoiceType === 'PURCHASE_CREDIT' || inv.invoiceType === 'PURCHASE_MAUND') {
              credit = Number(inv.netTotal || 0);
            }
            runningBalance += debit - credit;
          }
        }
      });

      const computedOpeningBalance = runningBalance;
      const rawEntries: any[] = [];

      // Collect entries from vouchers referencing this account
      vouchers.forEach(v => {
        const vDate = v.date ? v.date.split('T')[0] : '';
        if (vDate >= dateFrom && vDate <= dateTo) {
          v.lines?.forEach(l => {
            if (l.accountId === targetAccId) {
              rawEntries.push({
                date: v.date,
                voucherNo: v.voucherNo,
                description: v.narration || `${v.voucherType.replace('_', ' ')}`,
                debit: Number(l.debit || 0),
                credit: Number(l.credit || 0),
                timestamp: new Date(v.date).getTime()
              });
            }
          });
        }
      });

      // Collect entries from invoices referencing this account
      invoices.forEach(inv => {
        const invDate = inv.date ? inv.date.split('T')[0] : '';
        if (invDate >= dateFrom && invDate <= dateTo) {
          if (
            inv.accountName === acc.name ||
            inv.accountName === acc.id ||
            inv.accountName.toLowerCase() === acc.name.toLowerCase()
          ) {
            let debit = 0;
            let credit = 0;
            let desc = '';

            if (inv.invoiceType === 'SALES_CASH' || inv.invoiceType === 'SALES_CREDIT' || inv.invoiceType === 'SALES_MAUND') {
              debit = Number(inv.netTotal || 0);
              desc = `Sales Invoice #${inv.invoiceNo}`;
            } else if (inv.invoiceType === 'SALES_RETURN') {
              credit = Number(inv.netTotal || 0);
              desc = `Sales Return #${inv.invoiceNo}`;
            } else if (inv.invoiceType === 'PURCHASE_CASH' || inv.invoiceType === 'PURCHASE_CREDIT' || inv.invoiceType === 'PURCHASE_MAUND') {
              credit = Number(inv.netTotal || 0);
              desc = `Purchase Invoice #${inv.invoiceNo}`;
            } else if (inv.invoiceType === 'PURCHASE_RETURN') {
              debit = Number(inv.netTotal || 0);
              desc = `Purchase Return #${inv.invoiceNo}`;
            }

            if (debit > 0 || credit > 0) {
              rawEntries.push({
                date: inv.date,
                voucherNo: inv.invoiceNo,
                description: desc,
                items: inv.items || [],
                debit,
                credit,
                timestamp: new Date(inv.date).getTime()
              });
            }
          }
        }
      });

      rawEntries.sort((a, b) => a.timestamp - b.timestamp);

      const entries: any[] = [
        {
          date: 'Opening',
          voucherNo: 'OPENING',
          description: 'Opening Balance',
          debit: 0,
          credit: 0,
          balance: computedOpeningBalance
        }
      ];

      rawEntries.forEach(e => {
        runningBalance += e.debit - e.credit;
        entries.push({
          date: e.date,
          voucherNo: e.voucherNo,
          description: e.description,
          items: e.items,
          debit: e.debit,
          credit: e.credit,
          balance: runningBalance
        });
      });

      setAccountLedgerData(entries);
    } else {
      const prod = products.find(p => p.id === targetProdId);
      if (!prod) return;
      const invoices = await db.getInvoices();

      let runningQty = Number(prod.openingStock || 0);
      const entries: any[] = [
        {
          date: 'Opening',
          referenceNo: 'OPENING',
          transaction: 'Opening Stock',
          inQty: Number(prod.openingStock || 0),
          outQty: 0,
          rate: Number(prod.openingStockRate || 0),
          balanceQty: runningQty
        }
      ];

      invoices.forEach(inv => {
        const invDate = inv.date ? inv.date.split('T')[0] : '';
        if (invDate >= dateFrom && invDate <= dateTo) {
          inv.items?.forEach(item => {
            if (item.productId === targetProdId) {
              let inQty = 0;
              let outQty = 0;
              let transType = inv.invoiceType.replace('_', ' ');

              if (inv.invoiceType === 'PRODUCTION') {
                const qOut = Number(item.quantityOut || 0);
                const qIn = Number(item.quantityIn || 0);
                if (qOut > 0) {
                  outQty = qOut;
                  transType = `Production (Out/Consumed) - ${item.description || 'Raw Material'}`;
                } else if (qIn > 0) {
                  inQty = qIn;
                  transType = `Production (In/Yield) - ${item.description || 'Finished Goods'}`;
                } else {
                  // Fallback if saved with general quantity
                  inQty = Number(item.quantity || 0);
                  transType = `Production - ${item.description || ''}`;
                }
              } else {
                const isIn = inv.invoiceType.includes('PURCHASE') || inv.invoiceType.includes('SALES_RETURN');
                inQty = isIn ? Number(item.quantity || 0) : 0;
                outQty = !isIn ? Number(item.quantity || 0) : 0;
              }

              if (inQty > 0 || outQty > 0) {
                runningQty += inQty - outQty;
                entries.push({
                  date: inv.date,
                  referenceNo: inv.invoiceNo,
                  transaction: transType,
                  inQty,
                  outQty,
                  rate: Number(item.rate || 0),
                  balanceQty: runningQty
                });
              }
            }
          });
        }
      });

      setProductLedgerData(entries);
    }
  };

  const buildLedgerHtml = (): string => {
    const acc = accounts.find(a => a.id === selectedAccountId);
    const prod = products.find(p => p.id === selectedProductId);
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const compAddr = companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL';
    const compPhone = companyProfile?.phone || companyProfile?.mobile || '03023576036';
    const logoUrl = companyProfile?.logoUrl || '/logoittehad.png';

    const headerHtml = buildStandardReportHeaderHtml({
      companyName: compName,
      headOfficeAddress: compAddr,
      phone: compPhone,
      logoUrl: logoUrl,
      reportTitle: ledgerType === 'account' ? 'ACCOUNT LEDGER STATEMENT' : 'PRODUCT STOCK LEDGER',
      periodText: `${formatDate(dateFrom)} to ${formatDate(dateTo)}`,
      badgeCodeLabel: ledgerType === 'account' ? 'ACCOUNT CODE' : 'PRODUCT CODE',
      badgeCode: ledgerType === 'account' ? acc?.code || 'N/A' : prod?.productCode || 'N/A',
      badgeNameLabel: ledgerType === 'account' ? 'ACCOUNT NAME' : 'PRODUCT NAME',
      badgeName: ledgerType === 'account' ? acc?.name || 'N/A' : `${prod?.productName || 'N/A'} (${prod?.variety || ''})`,
      metaLines:
        ledgerType === 'account'
          ? [
              `<strong>Account Head:</strong> ${acc?.accountType || 'N/A'}`,
              acc?.phone ? `<strong>Phone:</strong> ${acc.phone}` : '',
              acc?.salesStaff ? `<strong>Sales Officer:</strong> ${acc.salesStaff}` : '',
              `<strong>Opening Balance:</strong> PKR ${Number(acc?.openingBalance || 0).toLocaleString()} ${acc?.openingBalanceType || 'Dr'}`,
              `<strong>Period:</strong> ${formatDate(dateFrom)} to ${formatDate(dateTo)}`
            ].filter(Boolean) as string[]
          : [
              `<strong>Pack Size:</strong> ${prod?.packSize || 'N/A'}`,
              `<strong>Sale Rate:</strong> PKR ${Number(prod?.saleRate || 0).toLocaleString()}`,
              `<strong>Opening Stock:</strong> ${prod?.openingStock || 0}`,
              `<strong>Period:</strong> ${formatDate(dateFrom)} to ${formatDate(dateTo)}`
            ].filter(Boolean) as string[]
    });

    let tableRows = '';
    let totalDebit = 0;
    let totalCredit = 0;
    let totalInQty = 0;
    let totalOutQty = 0;

    if (ledgerType === 'account') {
      accountLedgerData.forEach(e => {
        if (e.voucherNo !== 'OPENING') {
          totalDebit += Number(e.debit || 0);
          totalCredit += Number(e.credit || 0);
        }
      });
      const finalBalance = accountLedgerData.length > 0 ? accountLedgerData[accountLedgerData.length - 1].balance : 0;

      tableRows = accountLedgerData
        .map(
          e => `
        <tr>
          <td style="white-space:nowrap;font-family:monospace;font-size:10px;">${e.date === 'Opening' ? 'Opening' : formatDate(e.date)}</td>
          <td style="font-family:monospace;font-weight:bold;color:#065f46;">${e.voucherNo}</td>
          <td>
            <div style="font-weight:600;">${e.description}</div>
            ${
              e.items && e.items.length > 0
                ? `<div style="font-size:9.5px;color:#4b5563;margin-top:2px;">
                    ${e.items.map((it: any) => `${it.productName} (${it.quantity} ${it.unit || 'Bag'} @ ${it.rate})`).join(', ')}
                  </div>`
                : ''
            }
          </td>
          <td style="text-align:right;font-family:monospace;">${e.debit ? Number(e.debit).toLocaleString() : '-'}</td>
          <td style="text-align:right;font-family:monospace;">${e.credit ? Number(e.credit).toLocaleString() : '-'}</td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;">
            ${Number(e.balance).toLocaleString()} ${e.balance >= 0 ? 'Dr' : 'Cr'}
          </td>
        </tr>
      `
        )
        .join('');

      return `
        <div>
          ${headerHtml}
          <table>
            <thead>
              <tr>
                <th style="width:85px;">Date</th>
                <th style="width:115px;">Voucher / Ref #</th>
                <th>Description / Particulars</th>
                <th style="width:110px;text-align:right;">Debit (PKR)</th>
                <th style="width:110px;text-align:right;">Credit (PKR)</th>
                <th style="width:125px;text-align:right;">Balance (PKR)</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" style="text-align:right;font-weight:bold;">Total Transacted / Net Balance:</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;">PKR ${totalDebit.toLocaleString()}</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#b91c1c;">PKR ${totalCredit.toLocaleString()}</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;font-size:11.5px;">
                  PKR ${finalBalance.toLocaleString()} ${finalBalance >= 0 ? 'Dr' : 'Cr'}
                </td>
              </tr>
            </tfoot>
          </table>
          ${buildStandardReportFooterHtml(compName)}
        </div>
      `;
    } else {
      productLedgerData.forEach(e => {
        totalInQty += Number(e.inQty || 0);
        totalOutQty += Number(e.outQty || 0);
      });
      const finalBalanceQty = productLedgerData.length > 0 ? productLedgerData[productLedgerData.length - 1].balanceQty : 0;

      tableRows = productLedgerData
        .map(
          e => `
        <tr>
          <td style="white-space:nowrap;font-family:monospace;font-size:10px;">${e.date === 'Opening' ? 'Opening' : formatDate(e.date)}</td>
          <td style="font-family:monospace;font-weight:bold;color:#065f46;">${e.referenceNo}</td>
          <td style="font-weight:600;">${e.transaction}</td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#047857;">${e.inQty || '-'}</td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#b91c1c;">${e.outQty || '-'}</td>
          <td style="text-align:right;font-family:monospace;">${Number(e.rate || 0).toLocaleString()}</td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;">${e.balanceQty}</td>
        </tr>
      `
        )
        .join('');

      return `
        <div>
          ${headerHtml}
          <table>
            <thead>
              <tr>
                <th style="width:85px;">Date</th>
                <th style="width:115px;">Reference #</th>
                <th>Transaction Details</th>
                <th style="width:90px;text-align:right;">In Qty</th>
                <th style="width:90px;text-align:right;">Out Qty</th>
                <th style="width:100px;text-align:right;">Rate (PKR)</th>
                <th style="width:105px;text-align:right;">Balance Qty</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" style="text-align:right;font-weight:bold;">Total Movements / Closing Stock:</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#047857;">${totalInQty}</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#b91c1c;">${totalOutQty}</td>
                <td></td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;font-size:11.5px;">${finalBalanceQty}</td>
              </tr>
            </tfoot>
          </table>
          ${buildStandardReportFooterHtml(compName)}
        </div>
      `;
    }
  };

  const handlePrint = () => {
    const acc = accounts.find(a => a.id === selectedAccountId);
    const prod = products.find(p => p.id === selectedProductId);
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const name = ledgerType === 'account' ? acc?.name || 'Account' : prod?.productName || 'Product';
    const htmlContent = buildLedgerHtml();

    // Sends directly to the system default printer
    printReportDirect({
      title: `${compName} - ${name} Ledger`,
      htmlContent,
      landscape: false
    });
  };

  const exportPdf = async () => {
    const acc = accounts.find(a => a.id === selectedAccountId);
    const prod = products.find(p => p.id === selectedProductId);
    const name = ledgerType === 'account' ? acc?.name || 'Account' : prod?.productName || 'Product';
    const htmlContent = buildLedgerHtml();

    // Generates PDF looking identical to the printed report
    await downloadPdfFromReportHtml({
      htmlContent,
      filename: `${name.replace(/\s+/g, '_')}_ledger.pdf`,
      landscape: false
    });
  };

  const exportExcel = () => {
    const dataToExport = ledgerType === 'account' ? accountLedgerData : productLedgerData;
    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Ledger');
    const acc = accounts.find(a => a.id === selectedAccountId);
    const prod = products.find(p => p.id === selectedProductId);
    const name = ledgerType === 'account' ? acc?.name || 'account' : prod?.productName || 'product';
    XLSX.writeFile(workbook, `${name.replace(/\s+/g, '_')}_ledger.xlsx`);
  };

  let calcTotDebit = 0;
  let calcTotCredit = 0;
  accountLedgerData.forEach(e => {
    if (e.voucherNo !== 'OPENING') {
      calcTotDebit += Number(e.debit || 0);
      calcTotCredit += Number(e.credit || 0);
    }
  });
  const calcFinalBalance = accountLedgerData.length > 0 ? accountLedgerData[accountLedgerData.length - 1].balance : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Financial & Product Ledgers</h2>
          <p className="text-sm text-gray-500">
            View detailed account ledgers with running balance and product stock movements
          </p>
        </div>
        <div className="flex space-x-2 bg-white p-1 rounded-xl border border-gray-200">
          <button
            onClick={() => setLedgerType('account')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold ${
              ledgerType === 'account' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Account Ledger
          </button>
          <button
            onClick={() => setLedgerType('product')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold ${
              ledgerType === 'product' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Product Stock Ledger
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {ledgerType === 'account' ? (
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Select Account</label>
              <input
                type="text"
                placeholder="Search account by name or code..."
                value={accountSearch}
                onChange={e => setAccountSearch(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs mb-2 focus:border-emerald-600 focus:outline-hidden"
              />
              <select
                value={selectedAccountId}
                onChange={e => setSelectedAccountId(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
              >
                {accounts
                  .filter(
                    a =>
                      a.id === selectedAccountId ||
                      a.name.toLowerCase().includes(accountSearch.toLowerCase()) ||
                      a.code.toLowerCase().includes(accountSearch.toLowerCase())
                  )
                  .map(a => (
                    <option key={a.id} value={a.id}>
                      {a.code} - {a.name} ({a.accountType})
                    </option>
                  ))}
              </select>
            </div>
          ) : (
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Select Product / Seed</label>
              <select
                value={selectedProductId}
                onChange={e => setSelectedProductId(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
              >
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.productCode} - {p.productName} ({p.variety})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Date From</label>
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Date To</label>
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
            />
          </div>
        </div>

        <div className="flex justify-between items-center pt-2 flex-wrap gap-3">
          <button
            onClick={() => handleGenerate()}
            className="flex items-center space-x-2 bg-emerald-700 hover:bg-emerald-800 text-white px-5 py-2 rounded-lg text-sm font-semibold shadow-sm transition-colors"
          >
            <Search className="w-4 h-4" />
            <span>Generate Ledger</span>
          </button>
          <div className="flex space-x-2">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center space-x-1.5 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition-colors cursor-pointer"
              title="Print directly to Default Printer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Ledger</span>
            </button>
            <button
              type="button"
              onClick={exportPdf}
              className="flex items-center space-x-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 px-3 py-2 rounded-lg text-sm font-semibold border border-emerald-200 cursor-pointer"
              title="Download PDF matching print layout"
            >
              <Download className="w-4 h-4" />
              <span>PDF</span>
            </button>
            <button
              type="button"
              onClick={() => setShowPrintModal(true)}
              className="flex items-center space-x-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg text-sm font-semibold border border-gray-200 cursor-pointer"
              title="Preview Ledger on screen"
            >
              <Eye className="w-4 h-4" />
              <span>Preview</span>
            </button>
            <button
              type="button"
              onClick={exportExcel}
              className="flex items-center space-x-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 px-3 py-2 rounded-lg text-sm font-semibold border border-blue-200 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* Ledger Output Box */}
      <div id="printable-ledger-area" className="bg-white rounded-xl border border-gray-200 shadow-xs overflow-hidden p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between border-b-2 border-emerald-950 pb-5 gap-4">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-white border border-gray-300 rounded-xl overflow-hidden p-1 shadow-xs flex items-center justify-center shrink-0">
              <img
                src={companyProfile?.logoUrl || '/logoittehad.png'}
                alt="Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h2 className="text-xl font-black text-emerald-950 uppercase tracking-wide">
                {companyProfile?.companyName || 'AUGUSTA SEED COMPANY'}
              </h2>
              <p className="text-xs text-gray-600 font-medium">
                {companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL'} | PH:{' '}
                {companyProfile?.phone || companyProfile?.mobile || '03023576036'}
              </p>

              {/* ACCOUNT CODE AND ACCOUNT NAME UNDER THE TITLE */}
              {ledgerType === 'account' && selectedAccount && (
                <div className="mt-3 pt-2.5 border-t border-emerald-950/20">
                  <div className="flex flex-wrap items-center gap-x-2 text-base font-black text-gray-900 uppercase">
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Account Code:</span>
                    <span className="font-mono text-emerald-900 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300 text-sm">
                      {selectedAccount.code}
                    </span>
                    <span className="text-gray-400 mx-1">|</span>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Account Name:</span>
                    <span className="text-emerald-950 text-base font-black">{selectedAccount.name}</span>
                  </div>
                  <div className="text-xs text-gray-600 mt-1 flex flex-wrap gap-x-4">
                    <span>
                      Account Type: <strong className="text-gray-800">{selectedAccount.accountType}</strong>
                    </span>
                    {selectedAccount.phone && (
                      <span>
                        Phone: <strong className="text-gray-800">{selectedAccount.phone}</strong>
                      </span>
                    )}
                    {selectedAccount.salesStaff && (
                      <span>
                        Sales Staff: <strong className="text-gray-800">{selectedAccount.salesStaff}</strong>
                      </span>
                    )}
                    <span>
                      Opening Balance:{' '}
                      <strong className="text-emerald-800 font-mono font-bold">
                        PKR {Number(selectedAccount.openingBalance || 0).toLocaleString()} {selectedAccount.openingBalanceType}
                      </strong>
                    </span>
                  </div>
                </div>
              )}

              {/* PRODUCT CODE AND PRODUCT NAME UNDER THE TITLE */}
              {ledgerType === 'product' && selectedProduct && (
                <div className="mt-3 pt-2.5 border-t border-emerald-950/20">
                  <div className="flex flex-wrap items-center gap-x-2 text-base font-black text-gray-900 uppercase">
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Product Code:</span>
                    <span className="font-mono text-emerald-900 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300 text-sm">
                      {selectedProduct.productCode}
                    </span>
                    <span className="text-gray-400 mx-1">|</span>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Product Name:</span>
                    <span className="text-emerald-950 text-base font-black">
                      {selectedProduct.productName} ({selectedProduct.variety})
                    </span>
                  </div>
                  <div className="text-xs text-gray-600 mt-1 flex flex-wrap gap-x-4">
                    <span>
                      Pack Size: <strong className="text-gray-800">{selectedProduct.packSize}</strong>
                    </span>
                    <span>
                      Sale Rate:{' '}
                      <strong className="text-emerald-800 font-mono font-bold">
                        PKR {Number(selectedProduct.saleRate || 0).toLocaleString()}
                      </strong>
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="text-right shrink-0">
            <h3 className="text-sm font-bold text-emerald-800 uppercase tracking-wider">
              {ledgerType === 'account' ? 'Account Ledger Statement' : 'Product Stock Ledger'}
            </h3>
            <p className="text-xs text-gray-500 font-mono mt-0.5">
              Period: {dateFrom} to {dateTo}
            </p>
          </div>
        </div>

        {ledgerType === 'account' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse border border-gray-300">
              <thead>
                <tr className="border-b border-gray-300 text-xs font-bold uppercase text-gray-700 bg-gray-100">
                  <th className="py-2.5 px-3 border-r border-gray-300 w-28">Date</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 w-36">Voucher / Ref</th>
                  <th className="py-2.5 px-3 border-r border-gray-300">Description</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 text-right w-32">Debit (PKR)</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 text-right w-32">Credit (PKR)</th>
                  <th className="py-2.5 px-3 text-right w-36">Balance (PKR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-300 text-sm">
                {!hasGeneratedAccountLedger ? (
                  <tr>
                    <td colSpan={6} className="text-center py-16 text-gray-500">
                      <div className="flex flex-col items-center justify-center space-y-2">
                        <Search className="w-8 h-8 text-emerald-600 opacity-60 animate-bounce" />
                        <p className="font-semibold text-gray-700">Ready to Generate Account Ledger</p>
                        <p className="text-xs text-gray-400">Select an account and date range above, then click the "Generate Ledger" button to load and view the report.</p>
                      </div>
                    </td>
                  </tr>
                ) : accountLedgerData.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 text-gray-400">
                      No ledger transactions found for this account in the selected date range.
                    </td>
                  </tr>
                ) : (
                  accountLedgerData.map((e, idx) => (
                    <tr key={idx} className="hover:bg-gray-50/50 align-top">
                      <td className="py-3 px-3 border-r border-gray-300 text-gray-600 font-mono text-xs">{e.date}</td>
                      <td className="py-3 px-3 border-r border-gray-300 font-mono font-bold text-emerald-800">
                        {e.voucherNo}
                      </td>
                      <td className="py-3 px-3 border-r border-gray-300 text-gray-800">
                        <div className="font-semibold">{e.description}</div>
                        {e.items && e.items.length > 0 && (
                          <div className="mt-2 text-xs bg-gray-50 p-2.5 rounded-lg border border-gray-200">
                            <div className="font-bold text-gray-700 uppercase text-[10px] tracking-wider mb-1.5 flex items-center justify-between">
                              <span>Invoice Item Breakdown:</span>
                              <span className="text-emerald-700">{e.items.length} item(s)</span>
                            </div>
                            <table className="w-full text-left">
                              <thead>
                                <tr className="text-[10px] text-gray-500 border-b border-gray-200 uppercase">
                                  <th className="pb-1 font-semibold">Product</th>
                                  <th className="pb-1 font-semibold text-right">Qty</th>
                                  <th className="pb-1 font-semibold text-right">Rate</th>
                                  <th className="pb-1 font-semibold text-right">Disc</th>
                                  <th className="pb-1 font-semibold text-right">Amount</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-gray-100">
                                {e.items.map((item: any, iIdx: number) => (
                                  <tr key={iIdx}>
                                    <td className="py-1 text-gray-800 font-medium">
                                      {item.productName}{' '}
                                      {item.packSize ? (
                                        <span className="text-gray-500 text-[11px]">({item.packSize})</span>
                                      ) : (
                                        ''
                                      )}
                                    </td>
                                    <td className="py-1 text-right text-gray-600">
                                      {item.quantity} {item.unit}
                                    </td>
                                    <td className="py-1 text-right text-gray-600">
                                      {Number(item.rate || 0).toLocaleString()}
                                    </td>
                                    <td className="py-1 text-right text-gray-600">
                                      {Number(item.discount || 0).toLocaleString()}
                                    </td>
                                    <td className="py-1 text-right font-semibold text-gray-900">
                                      {Number(item.amount || 0).toLocaleString()}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 border-r border-gray-300 text-right font-semibold text-gray-800 font-mono">
                        {e.debit ? Number(e.debit).toLocaleString() : '-'}
                      </td>
                      <td className="py-3 px-3 border-r border-gray-300 text-right font-semibold text-gray-800 font-mono">
                        {e.credit ? Number(e.credit).toLocaleString() : '-'}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-emerald-800 font-mono">
                        {Number(e.balance).toLocaleString()} {e.balance >= 0 ? 'Dr' : 'Cr'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {ledgerType === 'account' && (
                <tfoot className="bg-gray-100 font-bold border-t-2 border-gray-300">
                  <tr>
                    <td colSpan={3} className="py-3 px-3 text-right uppercase text-gray-800">Total & Closing Balance:</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-900">
                      PKR {calcTotDebit.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-rose-700">
                      PKR {calcTotCredit.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-black text-emerald-950 text-base">
                      PKR {calcFinalBalance.toLocaleString()} {calcFinalBalance >= 0 ? 'Dr' : 'Cr'}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse border border-gray-300">
              <thead>
                <tr className="border-b border-gray-300 text-xs font-bold uppercase text-gray-700 bg-gray-100">
                  <th className="py-2.5 px-3 border-r border-gray-300 w-28">Date</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 w-36">Reference</th>
                  <th className="py-2.5 px-3 border-r border-gray-300">Transaction</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 text-right w-28">In Qty</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 text-right w-28">Out Qty</th>
                  <th className="py-2.5 px-3 border-r border-gray-300 text-right w-32">Rate (PKR)</th>
                  <th className="py-2.5 px-3 text-right w-32">Balance Qty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-300 text-sm">
                {productLedgerData.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-12 text-gray-400">
                      No stock transactions recorded for this product in the selected period.
                    </td>
                  </tr>
                ) : (
                  productLedgerData.map((e, idx) => (
                    <tr key={idx} className="hover:bg-gray-50/50">
                      <td className="py-2 px-3 border-r border-gray-300 text-gray-600 font-mono text-xs">{e.date}</td>
                      <td className="py-2 px-3 border-r border-gray-300 font-mono font-bold text-emerald-800">
                        {e.referenceNo}
                      </td>
                      <td className="py-2 px-3 border-r border-gray-300 font-medium text-gray-800">{e.transaction}</td>
                      <td className="py-2 px-3 border-r border-gray-300 text-right font-bold text-emerald-700 font-mono">
                        {e.inQty || '-'}
                      </td>
                      <td className="py-2 px-3 border-r border-gray-300 text-right font-bold text-rose-600 font-mono">
                        {e.outQty || '-'}
                      </td>
                      <td className="py-2 px-3 border-r border-gray-300 text-right text-gray-700 font-mono">
                        {e.rate ? Number(e.rate).toLocaleString() : '-'}
                      </td>
                      <td className="py-2 px-3 text-right font-black text-gray-900 font-mono">{e.balanceQty}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* PRINT PREVIEW MODAL */}
      {showPrintModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between px-6 py-4 bg-gray-900 text-white">
              <h3 className="font-bold text-lg flex items-center space-x-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <span>
                  {companyProfile?.companyName || 'AUGUSTA SEED COMPANY'} - Ledger Print Preview
                </span>
              </h3>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm cursor-pointer"
                  title="Send to Default Printer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Document</span>
                </button>
                <button
                  type="button"
                  onClick={exportPdf}
                  className="flex items-center space-x-1.5 bg-gray-700 hover:bg-gray-600 text-white px-3 py-2 rounded-lg text-sm font-semibold transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Sheet Preview */}
            <div className="p-8 overflow-y-auto bg-gray-50 flex-1">
              <div className="bg-white p-8 border border-gray-300 shadow-sm rounded-lg max-w-3xl mx-auto space-y-6 text-gray-900">
                {/* Header */}
                <div className="flex items-start justify-between border-b-2 border-emerald-950 pb-4">
                  <div className="flex items-start space-x-3">
                    <img
                      src={companyProfile?.logoUrl || '/logoittehad.png'}
                      alt="Logo"
                      className="w-14 h-14 object-contain"
                    />
                    <div>
                      <h2 className="text-xl font-black text-emerald-950 uppercase tracking-wide">
                        {companyProfile?.companyName || 'AUGUSTA SEED COMPANY'}
                      </h2>
                      <p className="text-xs text-gray-600">
                        {companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL'} | PH:{' '}
                        {companyProfile?.phone || companyProfile?.mobile || '03023576036'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">OFFICIAL LEDGER</div>
                    <div className="text-[10px] text-gray-500 font-mono mt-0.5">Printed: {new Date().toLocaleDateString()}</div>
                  </div>
                </div>

                {/* Account Code & Name Title Box */}
                {ledgerType === 'account' && selectedAccount ? (
                  <div className="bg-emerald-50 border border-emerald-300 rounded-lg p-3">
                    <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                      ACCOUNT LEDGER STATEMENT
                    </div>
                    <div className="text-base font-black text-gray-900 uppercase mt-1 flex flex-wrap items-center gap-2">
                      <span className="bg-emerald-900 text-white font-mono text-xs px-2 py-0.5 rounded">
                        CODE: {selectedAccount.code}
                      </span>
                      <span>NAME: {selectedAccount.name}</span>
                    </div>
                    <div className="text-xs text-gray-600 mt-1 flex flex-wrap gap-x-4">
                      <span>Account Head: <strong>{selectedAccount.accountType}</strong></span>
                      {selectedAccount.phone && <span>Contact: <strong>{selectedAccount.phone}</strong></span>}
                      {selectedAccount.salesStaff && <span>Sales Officer: <strong>{selectedAccount.salesStaff}</strong></span>}
                      <span>Period: <strong>{dateFrom} to {dateTo}</strong></span>
                    </div>
                  </div>
                ) : (
                  selectedProduct && (
                    <div className="bg-emerald-50 border border-emerald-300 rounded-lg p-3">
                      <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                        PRODUCT STOCK LEDGER
                      </div>
                      <div className="text-base font-black text-gray-900 uppercase mt-1 flex flex-wrap items-center gap-2">
                        <span className="bg-emerald-900 text-white font-mono text-xs px-2 py-0.5 rounded">
                          CODE: {selectedProduct.productCode}
                        </span>
                        <span>NAME: {selectedProduct.productName} ({selectedProduct.variety})</span>
                      </div>
                      <div className="text-xs text-gray-600 mt-1 flex flex-wrap gap-x-4">
                        <span>Pack Size: <strong>{selectedProduct.packSize}</strong></span>
                        <span>Period: <strong>{dateFrom} to {dateTo}</strong></span>
                      </div>
                    </div>
                  )
                )}

                {/* Table */}
                <table className="w-full text-left border-collapse border border-gray-300 text-xs">
                  <thead>
                    <tr className="bg-emerald-950 text-white font-bold uppercase text-[10px]">
                      {ledgerType === 'account' ? (
                        <>
                          <th className="p-2 border border-emerald-950">Date</th>
                          <th className="p-2 border border-emerald-950">Ref #</th>
                          <th className="p-2 border border-emerald-950">Description</th>
                          <th className="p-2 border border-emerald-950 text-right">Debit</th>
                          <th className="p-2 border border-emerald-950 text-right">Credit</th>
                          <th className="p-2 border border-emerald-950 text-right">Balance</th>
                        </>
                      ) : (
                        <>
                          <th className="p-2 border border-emerald-950">Date</th>
                          <th className="p-2 border border-emerald-950">Ref #</th>
                          <th className="p-2 border border-emerald-950">Transaction</th>
                          <th className="p-2 border border-emerald-950 text-right">In</th>
                          <th className="p-2 border border-emerald-950 text-right">Out</th>
                          <th className="p-2 border border-emerald-950 text-right">Rate</th>
                          <th className="p-2 border border-emerald-950 text-right">Balance Qty</th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {ledgerType === 'account'
                      ? accountLedgerData.map((e, idx) => (
                          <tr key={idx} className="border-b border-gray-200">
                            <td className="p-2 border font-mono">{e.date}</td>
                            <td className="p-2 border font-mono font-bold text-emerald-800">{e.voucherNo}</td>
                            <td className="p-2 border font-medium">{e.description}</td>
                            <td className="p-2 border text-right font-mono">{e.debit ? Number(e.debit).toLocaleString() : '-'}</td>
                            <td className="p-2 border text-right font-mono">{e.credit ? Number(e.credit).toLocaleString() : '-'}</td>
                            <td className="p-2 border text-right font-mono font-bold text-emerald-900">
                              {Number(e.balance).toLocaleString()} {e.balance >= 0 ? 'Dr' : 'Cr'}
                            </td>
                          </tr>
                        ))
                      : productLedgerData.map((e, idx) => (
                          <tr key={idx} className="border-b border-gray-200">
                            <td className="p-2 border font-mono">{e.date}</td>
                            <td className="p-2 border font-mono font-bold text-emerald-800">{e.referenceNo}</td>
                            <td className="p-2 border font-medium">{e.transaction}</td>
                            <td className="p-2 border text-right font-mono text-emerald-700 font-bold">{e.inQty || '-'}</td>
                            <td className="p-2 border text-right font-mono text-rose-700 font-bold">{e.outQty || '-'}</td>
                            <td className="p-2 border text-right font-mono">{e.rate ? Number(e.rate).toLocaleString() : '-'}</td>
                            <td className="p-2 border text-right font-mono font-bold">{e.balanceQty}</td>
                          </tr>
                        ))}
                  </tbody>
                  {ledgerType === 'account' && (
                    <tfoot>
                      <tr className="bg-emerald-50 font-bold border-t-2 border-emerald-950 text-gray-900">
                        <td colSpan={3} className="p-2 border text-right uppercase">Total & Closing Balance:</td>
                        <td className="p-2 border text-right font-mono font-bold text-emerald-900">
                          PKR {calcTotDebit.toLocaleString()}
                        </td>
                        <td className="p-2 border text-right font-mono font-bold text-rose-700">
                          PKR {calcTotCredit.toLocaleString()}
                        </td>
                        <td className="p-2 border text-right font-mono font-black text-emerald-950">
                          PKR {calcFinalBalance.toLocaleString()} {calcFinalBalance >= 0 ? 'Dr' : 'Cr'}
                        </td>
                      </tr>
                    </tfoot>
                  )}
                </table>

                {/* Signatures */}
                <div className="pt-8 border-t border-gray-300 grid grid-cols-2 gap-8 text-xs font-semibold">
                  <div className="border-t border-gray-800 pt-2 text-center">Accountant Signature</div>
                  <div className="border-t border-gray-800 pt-2 text-center">Authorized Officer Signature</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

