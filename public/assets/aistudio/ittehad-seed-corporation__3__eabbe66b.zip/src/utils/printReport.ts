/**
 * Standardized Direct Print & Report Formatting Utility
 * Directly sends formatted reports to the user's default printer dialog
 * and ensures 1:1 fidelity between print output and PDF reports.
 */

export interface PrintReportOptions {
  companyName: string;
  headOfficeAddress: string;
  phone: string;
  logoUrl?: string;
  reportTitle: string;
  accountCode?: string;
  accountName?: string;
  accountType?: string;
  accountPhone?: string;
  salesStaff?: string;
  openingBalance?: string;
  productCode?: string;
  productName?: string;
  packSize?: string;
  saleRate?: string;
  period: string;
  tableHead: string[];
  tableRows: (string | number)[][];
  columnAlignments?: ('left' | 'right' | 'center')[];
  columnWidths?: string[];
  summaryBoxes?: { label: string; value: string }[];
  isLandscape?: boolean;
}

export function sendToDefaultPrinter(htmlDocument: string) {
  // Remove any existing print iframe
  const existing = document.getElementById('system-direct-print-iframe');
  if (existing) {
    existing.remove();
  }

  // Create isolated, hidden iframe
  const iframe = document.createElement('iframe');
  iframe.id = 'system-direct-print-iframe';
  iframe.style.position = 'fixed';
  iframe.style.top = '0';
  iframe.style.left = '0';
  iframe.style.width = '1px';
  iframe.style.height = '1px';
  iframe.style.border = 'none';
  iframe.style.opacity = '0.01';
  iframe.style.pointerEvents = 'none';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) {
    window.print();
    return;
  }

  doc.open();
  doc.write(htmlDocument);
  doc.close();

  // Wait for font and DOM layout, then trigger system default printer prompt
  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('Iframe print error, falling back to window.print():', e);
      window.print();
    }
  }, 350);
}

export function buildStandardReportHtml(opts: PrintReportOptions): string {
  const isAccount = Boolean(opts.accountCode || opts.accountName);
  const isProduct = Boolean(opts.productCode || opts.productName);

  const headCols = opts.tableHead
    .map((col, idx) => {
      const align = opts.columnAlignments?.[idx] || 'left';
      const width = opts.columnWidths?.[idx] ? `width:${opts.columnWidths[idx]};` : '';
      return `<th style="text-align:${align};${width}">${col}</th>`;
    })
    .join('');

  const bodyRows = opts.tableRows
    .map(row => {
      const cells = row
        .map((cell, idx) => {
          const align = opts.columnAlignments?.[idx] || 'left';
          const isMono = align === 'right' || idx === 0 || idx === 1;
          const fontMono = isMono ? 'font-family:monospace;' : '';
          return `<td style="text-align:${align};${fontMono}">${cell ?? '-'}</td>`;
        })
        .join('');
      return `<tr>${cells}</tr>`;
    })
    .join('');

  let bannerHtml = '';
  if (isAccount) {
    bannerHtml = `
      <div class="account-header-box">
        <div class="ledger-tag">${opts.reportTitle}</div>
        <div class="account-title-line">
          ${opts.accountCode ? `<span class="code-tag">CODE: ${opts.accountCode}</span>` : ''}
          <span class="account-name-text">NAME: ${opts.accountName || 'N/A'}</span>
        </div>
        <div class="meta-line">
          ${opts.accountType ? `<span><strong>Account Head:</strong> ${opts.accountType}</span>` : ''}
          ${opts.accountPhone ? `<span> | <strong>Phone:</strong> ${opts.accountPhone}</span>` : ''}
          ${opts.salesStaff ? `<span> | <strong>Sales Officer:</strong> ${opts.salesStaff}</span>` : ''}
          ${opts.openingBalance ? `<span> | <strong>Opening Balance:</strong> ${opts.openingBalance}</span>` : ''}
          <span> | <strong>Statement Period:</strong> ${opts.period}</span>
        </div>
      </div>
    `;
  } else if (isProduct) {
    bannerHtml = `
      <div class="account-header-box">
        <div class="ledger-tag">${opts.reportTitle}</div>
        <div class="account-title-line">
          ${opts.productCode ? `<span class="code-tag">CODE: ${opts.productCode}</span>` : ''}
          <span class="account-name-text">PRODUCT: ${opts.productName || 'N/A'}</span>
        </div>
        <div class="meta-line">
          ${opts.packSize ? `<span><strong>Pack Size:</strong> ${opts.packSize}</span>` : ''}
          ${opts.saleRate ? `<span> | <strong>Sale Rate:</strong> ${opts.saleRate}</span>` : ''}
          <span> | <strong>Statement Period:</strong> ${opts.period}</span>
        </div>
      </div>
    `;
  } else {
    bannerHtml = `
      <div class="account-header-box">
        <div class="ledger-tag">${opts.reportTitle}</div>
        <div class="meta-line">
          <span><strong>Statement Period:</strong> ${opts.period}</span>
        </div>
      </div>
    `;
  }

  const summariesHtml =
    opts.summaryBoxes && opts.summaryBoxes.length > 0
      ? `
        <div class="summary-row">
          ${opts.summaryBoxes
            .map(
              s => `
            <div class="summary-box">
              <span class="summary-label">${s.label}:</span>
              <span class="summary-val">${s.value}</span>
            </div>
          `
            )
            .join('')}
        </div>
      `
      : '';

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8" />
      <title>${opts.companyName} - ${opts.reportTitle}</title>
      <style>
        @page { size: ${opts.isLandscape ? 'A4 landscape' : 'A4 portrait'}; margin: 10mm; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 11px; color: #111; margin: 0; padding: 0; }
        .header-bar { display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #064e3b; padding-bottom: 8px; margin-bottom: 12px; }
        .logo-wrap { display: flex; align-items: center; gap: 12px; }
        .logo-img { width: 50px; height: 50px; object-fit: contain; }
        .company-name { font-size: 18px; font-weight: 900; color: #064e3b; text-transform: uppercase; margin: 0; }
        .company-info { font-size: 11px; color: #4b5563; margin-top: 2px; }
        .account-header-box { background: #f0fdf4; border: 1.5px solid #a7f3d0; border-radius: 6px; padding: 10px 14px; margin-bottom: 12px; }
        .ledger-tag { font-size: 10px; font-weight: 800; color: #047857; text-transform: uppercase; letter-spacing: 0.5px; }
        .account-title-line { font-size: 15px; font-weight: 900; color: #111827; margin: 4px 0; text-transform: uppercase; display: flex; align-items: center; gap: 10px; }
        .code-tag { background: #064e3b; color: #fff; padding: 2px 7px; border-radius: 4px; font-family: monospace; font-size: 12px; }
        .account-name-text { color: #064e3b; }
        .meta-line { font-size: 10.5px; color: #4b5563; margin-top: 3px; }
        table { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 10.5px; }
        th { background: #064e3b; color: #fff; text-align: left; padding: 6px 8px; font-weight: 700; text-transform: uppercase; font-size: 9.5px; border: 1px solid #064e3b; }
        td { padding: 5px 8px; border: 1px solid #d1d5db; vertical-align: top; }
        tr:nth-child(even) { background-color: #f9fafb; }
        .summary-row { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 12px; padding: 8px 12px; background: #f3f4f6; border: 1px solid #e5e7eb; border-radius: 6px; }
        .summary-box { display: flex; align-items: center; gap: 6px; font-size: 11px; }
        .summary-label { font-weight: 700; color: #374151; }
        .summary-val { font-family: monospace; font-weight: 800; color: #064e3b; }
        .footer-line { margin-top: 30px; padding-top: 15px; border-top: 1px solid #9ca3af; display: flex; justify-content: space-between; font-size: 10px; color: #4b5563; }
        .sign-col { width: 160px; border-top: 1px solid #111; text-align: center; padding-top: 4px; font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="header-bar">
        <div class="logo-wrap">
          ${opts.logoUrl ? `<img src="${opts.logoUrl}" class="logo-img" alt="Logo" />` : ''}
          <div>
            <h1 class="company-name">${opts.companyName}</h1>
            <div class="company-info">${opts.headOfficeAddress} | PH: ${opts.phone}</div>
          </div>
        </div>
        <div style="text-align:right;">
          <div style="font-weight:bold;color:#064e3b;font-size:11px;">OFFICIAL REPORT</div>
          <div style="font-size:9.5px;color:#6b7280;margin-top:2px;">Printed: ${new Date().toLocaleDateString()}</div>
        </div>
      </div>

      ${bannerHtml}

      <table>
        <thead>
          <tr>${headCols}</tr>
        </thead>
        <tbody>
          ${bodyRows}
        </tbody>
      </table>

      ${summariesHtml}

      <div class="footer-line">
        <div>Report Generated by ${opts.companyName} ERP System</div>
        <div class="sign-col">Accountant Signature</div>
        <div class="sign-col">Authorized Officer</div>
      </div>
    </body>
    </html>
  `;
}
